<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainWindow
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainWindow))
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripProgressBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.statusLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TextBoxSample = New System.Windows.Forms.TextBox()
        Me.TextBoxMeasNo = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBoxPosition = New System.Windows.Forms.GroupBox()
        Me.ButtonCopyDown = New System.Windows.Forms.Button()
        Me.focussearchButton = New System.Windows.Forms.Button()
        Me.ButtonCopyUp = New System.Windows.Forms.Button()
        Me.zsearchText = New System.Windows.Forms.TextBox()
        Me.ysearchText = New System.Windows.Forms.TextBox()
        Me.xsearchText = New System.Windows.Forms.TextBox()
        Me.ZLabel = New System.Windows.Forms.Label()
        Me.zsearchScroll = New System.Windows.Forms.HScrollBar()
        Me.YLabel = New System.Windows.Forms.Label()
        Me.ysearchScroll = New System.Windows.Forms.HScrollBar()
        Me.XLabel = New System.Windows.Forms.Label()
        Me.xsearchScroll = New System.Windows.Forms.HScrollBar()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ButtonCaliLC2 = New System.Windows.Forms.Button()
        Me.ButtonCaliLC1 = New System.Windows.Forms.Button()
        Me.TextBoxCaliDelay = New System.Windows.Forms.MaskedTextBox()
        Me.TextBoxCaliSteps = New System.Windows.Forms.MaskedTextBox()
        Me.TextBoxCaliEnd = New System.Windows.Forms.MaskedTextBox()
        Me.TextBoxCaliStart = New System.Windows.Forms.MaskedTextBox()
        Me.CheckBoxCamTrigger = New System.Windows.Forms.CheckBox()
        Me.OnTargetCheck = New System.Windows.Forms.CheckBox()
        Me.averageText = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.stopButton = New System.Windows.Forms.Button()
        Me.measureButton = New System.Windows.Forms.Button()
        Me.interruptButton = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBoxMultiview = New System.Windows.Forms.PictureBox()
        Me.Label_Multiview = New System.Windows.Forms.Label()
        Me.GroupBoxPostprocessing = New System.Windows.Forms.GroupBox()
        Me.showautocontrastButton = New System.Windows.Forms.Button()
        Me.showcontrastcolorButton = New System.Windows.Forms.Button()
        Me.showreflexcolorButton = New System.Windows.Forms.Button()
        Me.showautocontrastreflexButton = New System.Windows.Forms.Button()
        Me.GroupBoxMeasuredValues = New System.Windows.Forms.GroupBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.reflexionText = New System.Windows.Forms.TextBox()
        Me.pdsignalText = New System.Windows.Forms.TextBox()
        Me.referenceText = New System.Windows.Forms.TextBox()
        Me.normsignalText = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.reflexnormsignalText = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.ShowSatCheckBox = New System.Windows.Forms.CheckBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBoxPreview = New System.Windows.Forms.PictureBox()
        Me.GroupBoxMeasurementResult = New System.Windows.Forms.GroupBox()
        Me.TabControlView = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label_Preview = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.ButtonTransferRefl = New System.Windows.Forms.Button()
        Me.ButtonTransferTran = New System.Windows.Forms.Button()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.ButtonFF = New System.Windows.Forms.Button()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.mouseoverzText = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.finescan_range = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.finescan_step = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.TextBoxFFcenter = New System.Windows.Forms.TextBox()
        Me.transminText = New System.Windows.Forms.TextBox()
        Me.reflexmaxText = New System.Windows.Forms.TextBox()
        Me.TextBoxFFxpos = New System.Windows.Forms.TextBox()
        Me.TextBoxFFypos = New System.Windows.Forms.TextBox()
        Me.PictureBox_trans = New System.Windows.Forms.PictureBox()
        Me.PictureBox_refl = New System.Windows.Forms.PictureBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.SerialPortPiezo = New System.IO.Ports.SerialPort(Me.components)
        Me.GroupBoxPresettings = New System.Windows.Forms.GroupBox()
        Me.SmileyBox = New System.Windows.Forms.PictureBox()
        Me.TextBoxWavelength = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBoxMeasName = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBoxPol = New System.Windows.Forms.TextBox()
        Me.GroupBoxCalcScanfield = New System.Windows.Forms.GroupBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.zstepcalc = New System.Windows.Forms.TextBox()
        Me.ystepcalc = New System.Windows.Forms.TextBox()
        Me.xstepcalc = New System.Windows.Forms.TextBox()
        Me.zcalcendText = New System.Windows.Forms.TextBox()
        Me.ycalcendText = New System.Windows.Forms.TextBox()
        Me.xcalcendText = New System.Windows.Forms.TextBox()
        Me.zcalcstartText = New System.Windows.Forms.TextBox()
        Me.ycalcstartText = New System.Windows.Forms.TextBox()
        Me.xcalcstartText = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.otherinfosText = New System.Windows.Forms.TextBox()
        Me.GroupBoxSettingsList = New System.Windows.Forms.GroupBox()
        Me.Surv1 = New System.Windows.Forms.TextBox()
        Me.Surv2 = New System.Windows.Forms.TextBox()
        Me.Surv3 = New System.Windows.Forms.TextBox()
        Me.Surv4 = New System.Windows.Forms.TextBox()
        Me.TextBoxZoom = New System.Windows.Forms.TextBox()
        Me.Label_zoom = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBoxTime = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TabControlCommand = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ButtonRootdirIMG = New System.Windows.Forms.Button()
        Me.TextBoxRootdirIMG = New System.Windows.Forms.TextBox()
        Me.CheckBoxImageCheck = New System.Windows.Forms.CheckBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.MaskedTextBox5 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox6 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox7 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox8 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox2 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox3 = New System.Windows.Forms.MaskedTextBox()
        Me.MaskedTextBox4 = New System.Windows.Forms.MaskedTextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.ButtonOffset = New System.Windows.Forms.Button()
        Me.TextBoxOffRefe = New System.Windows.Forms.TextBox()
        Me.TextBoxOffRefl = New System.Windows.Forms.TextBox()
        Me.TextBoxOffTran = New System.Windows.Forms.TextBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBoxRootdir = New System.Windows.Forms.TextBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.FolderBrowserDialogRootdir = New System.Windows.Forms.FolderBrowserDialog()
        Me.GroupBoxPositionEntry = New System.Windows.Forms.GroupBox()
        Me.TextBoxMaxStepZ = New System.Windows.Forms.TextBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.ListBoxMeasureFields = New System.Windows.Forms.ListBox()
        Me.previewButton = New System.Windows.Forms.Button()
        Me.calculateButton = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.TextBoxMaxStep = New System.Windows.Forms.TextBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.zstepsizeText = New System.Windows.Forms.TextBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.zstepText = New System.Windows.Forms.TextBox()
        Me.zposText = New System.Windows.Forms.TextBox()
        Me.ystepsizeText = New System.Windows.Forms.TextBox()
        Me.yposText = New System.Windows.Forms.TextBox()
        Me.ystepText = New System.Windows.Forms.TextBox()
        Me.xstepsizeText = New System.Windows.Forms.TextBox()
        Me.xposText = New System.Windows.Forms.TextBox()
        Me.xstepText = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ArcOptixV4Step = New System.Windows.Forms.DomainUpDown()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.ArcOptixV3Step = New System.Windows.Forms.DomainUpDown()
        Me.ArcOptixV3 = New System.Windows.Forms.NumericUpDown()
        Me.ArcOptixV4 = New System.Windows.Forms.NumericUpDown()
        Me.ButtonRootdir = New System.Windows.Forms.Button()
        Me.StatusStrip.SuspendLayout()
        Me.GroupBoxPosition.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBoxMultiview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxPostprocessing.SuspendLayout()
        Me.GroupBoxMeasuredValues.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBoxPreview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxMeasurementResult.SuspendLayout()
        Me.TabControlView.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.PictureBox_trans, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_refl, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxPresettings.SuspendLayout()
        CType(Me.SmileyBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxCalcScanfield.SuspendLayout()
        Me.GroupBoxSettingsList.SuspendLayout()
        Me.TabControlCommand.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBoxPositionEntry.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.ArcOptixV3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ArcOptixV4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusStrip
        '
        Me.StatusStrip.BackColor = System.Drawing.SystemColors.Control
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel, Me.ToolStripProgressBar, Me.statusLabel})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 547)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(952, 26)
        Me.StatusStrip.SizingGrip = False
        Me.StatusStrip.TabIndex = 15
        Me.StatusStrip.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(38, 21)
        Me.ToolStripStatusLabel.Text = "Status"
        '
        'ToolStripProgressBar
        '
        Me.ToolStripProgressBar.ForeColor = System.Drawing.Color.Maroon
        Me.ToolStripProgressBar.Name = "ToolStripProgressBar"
        Me.ToolStripProgressBar.Size = New System.Drawing.Size(435, 20)
        '
        'statusLabel
        '
        Me.statusLabel.ForeColor = System.Drawing.Color.Maroon
        Me.statusLabel.Name = "statusLabel"
        Me.statusLabel.Size = New System.Drawing.Size(462, 21)
        Me.statusLabel.Spring = True
        Me.statusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TextBoxSample
        '
        Me.TextBoxSample.Location = New System.Drawing.Point(75, 66)
        Me.TextBoxSample.Name = "TextBoxSample"
        Me.TextBoxSample.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxSample.TabIndex = 104
        Me.TextBoxSample.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMeasNo
        '
        Me.TextBoxMeasNo.Location = New System.Drawing.Point(138, 66)
        Me.TextBoxMeasNo.Name = "TextBoxMeasNo"
        Me.TextBoxMeasNo.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxMeasNo.TabIndex = 105
        Me.TextBoxMeasNo.Text = "0"
        Me.TextBoxMeasNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.ForeColor = System.Drawing.Color.Black
        Me.Label39.Location = New System.Drawing.Point(202, 69)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(53, 13)
        Me.Label39.TabIndex = 23
        Me.Label39.Text = "meas. no."
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(8, 69)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(40, 13)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "sample"
        '
        'GroupBoxPosition
        '
        Me.GroupBoxPosition.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBoxPosition.Controls.Add(Me.ButtonCopyDown)
        Me.GroupBoxPosition.Controls.Add(Me.focussearchButton)
        Me.GroupBoxPosition.Controls.Add(Me.ButtonCopyUp)
        Me.GroupBoxPosition.Controls.Add(Me.zsearchText)
        Me.GroupBoxPosition.Controls.Add(Me.ysearchText)
        Me.GroupBoxPosition.Controls.Add(Me.xsearchText)
        Me.GroupBoxPosition.Controls.Add(Me.ZLabel)
        Me.GroupBoxPosition.Controls.Add(Me.zsearchScroll)
        Me.GroupBoxPosition.Controls.Add(Me.YLabel)
        Me.GroupBoxPosition.Controls.Add(Me.ysearchScroll)
        Me.GroupBoxPosition.Controls.Add(Me.XLabel)
        Me.GroupBoxPosition.Controls.Add(Me.xsearchScroll)
        Me.GroupBoxPosition.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBoxPosition.Location = New System.Drawing.Point(10, 46)
        Me.GroupBoxPosition.Name = "GroupBoxPosition"
        Me.GroupBoxPosition.Size = New System.Drawing.Size(466, 124)
        Me.GroupBoxPosition.TabIndex = 6
        Me.GroupBoxPosition.TabStop = False
        Me.GroupBoxPosition.Text = "manual position search"
        '
        'ButtonCopyDown
        '
        Me.ButtonCopyDown.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonCopyDown.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonCopyDown.Image = CType(resources.GetObject("ButtonCopyDown.Image"), System.Drawing.Image)
        Me.ButtonCopyDown.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ButtonCopyDown.Location = New System.Drawing.Point(25, 92)
        Me.ButtonCopyDown.Name = "ButtonCopyDown"
        Me.ButtonCopyDown.Size = New System.Drawing.Size(90, 25)
        Me.ButtonCopyDown.TabIndex = 15
        Me.ButtonCopyDown.Text = "copy position"
        Me.ButtonCopyDown.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ButtonCopyDown.UseVisualStyleBackColor = True
        '
        'focussearchButton
        '
        Me.focussearchButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.focussearchButton.ForeColor = System.Drawing.Color.Maroon
        Me.focussearchButton.Image = CType(resources.GetObject("focussearchButton.Image"), System.Drawing.Image)
        Me.focussearchButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.focussearchButton.Location = New System.Drawing.Point(381, 92)
        Me.focussearchButton.Name = "focussearchButton"
        Me.focussearchButton.Size = New System.Drawing.Size(79, 25)
        Me.focussearchButton.TabIndex = 14
        Me.focussearchButton.Text = "find focus"
        Me.focussearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.focussearchButton.UseVisualStyleBackColor = True
        '
        'ButtonCopyUp
        '
        Me.ButtonCopyUp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonCopyUp.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonCopyUp.Image = CType(resources.GetObject("ButtonCopyUp.Image"), System.Drawing.Image)
        Me.ButtonCopyUp.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ButtonCopyUp.Location = New System.Drawing.Point(115, 92)
        Me.ButtonCopyUp.Name = "ButtonCopyUp"
        Me.ButtonCopyUp.Size = New System.Drawing.Size(90, 25)
        Me.ButtonCopyUp.TabIndex = 13
        Me.ButtonCopyUp.Text = "copy position"
        Me.ButtonCopyUp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ButtonCopyUp.UseVisualStyleBackColor = True
        '
        'zsearchText
        '
        Me.zsearchText.Location = New System.Drawing.Point(412, 66)
        Me.zsearchText.Name = "zsearchText"
        Me.zsearchText.Size = New System.Drawing.Size(48, 20)
        Me.zsearchText.TabIndex = 12
        Me.zsearchText.Text = "10"
        Me.zsearchText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ysearchText
        '
        Me.ysearchText.Location = New System.Drawing.Point(412, 42)
        Me.ysearchText.Name = "ysearchText"
        Me.ysearchText.Size = New System.Drawing.Size(48, 20)
        Me.ysearchText.TabIndex = 11
        Me.ysearchText.Text = "100"
        Me.ysearchText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'xsearchText
        '
        Me.xsearchText.Location = New System.Drawing.Point(412, 18)
        Me.xsearchText.Name = "xsearchText"
        Me.xsearchText.Size = New System.Drawing.Size(48, 20)
        Me.xsearchText.TabIndex = 3
        Me.xsearchText.Text = "100"
        Me.xsearchText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ZLabel
        '
        Me.ZLabel.AutoSize = True
        Me.ZLabel.ForeColor = System.Drawing.Color.Black
        Me.ZLabel.Location = New System.Drawing.Point(8, 69)
        Me.ZLabel.Name = "ZLabel"
        Me.ZLabel.Size = New System.Drawing.Size(14, 13)
        Me.ZLabel.TabIndex = 10
        Me.ZLabel.Text = "Z"
        '
        'zsearchScroll
        '
        Me.zsearchScroll.Location = New System.Drawing.Point(25, 67)
        Me.zsearchScroll.Maximum = 20000
        Me.zsearchScroll.Name = "zsearchScroll"
        Me.zsearchScroll.Size = New System.Drawing.Size(381, 18)
        Me.zsearchScroll.TabIndex = 9
        Me.zsearchScroll.Value = 10000
        '
        'YLabel
        '
        Me.YLabel.AutoSize = True
        Me.YLabel.ForeColor = System.Drawing.Color.Black
        Me.YLabel.Location = New System.Drawing.Point(8, 45)
        Me.YLabel.Name = "YLabel"
        Me.YLabel.Size = New System.Drawing.Size(14, 13)
        Me.YLabel.TabIndex = 8
        Me.YLabel.Text = "Y"
        '
        'ysearchScroll
        '
        Me.ysearchScroll.Location = New System.Drawing.Point(25, 43)
        Me.ysearchScroll.Maximum = 200000
        Me.ysearchScroll.Name = "ysearchScroll"
        Me.ysearchScroll.Size = New System.Drawing.Size(381, 18)
        Me.ysearchScroll.TabIndex = 7
        Me.ysearchScroll.Value = 100000
        '
        'XLabel
        '
        Me.XLabel.AutoSize = True
        Me.XLabel.ForeColor = System.Drawing.Color.Black
        Me.XLabel.Location = New System.Drawing.Point(8, 21)
        Me.XLabel.Name = "XLabel"
        Me.XLabel.Size = New System.Drawing.Size(14, 13)
        Me.XLabel.TabIndex = 6
        Me.XLabel.Text = "X"
        '
        'xsearchScroll
        '
        Me.xsearchScroll.Location = New System.Drawing.Point(25, 19)
        Me.xsearchScroll.Maximum = 200000
        Me.xsearchScroll.Name = "xsearchScroll"
        Me.xsearchScroll.Size = New System.Drawing.Size(381, 18)
        Me.xsearchScroll.TabIndex = 0
        Me.xsearchScroll.Value = 100000
        '
        'Button1
        '
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.ForeColor = System.Drawing.Color.Maroon
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.Location = New System.Drawing.Point(220, 300)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(60, 25)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "click me"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ButtonCaliLC2
        '
        Me.ButtonCaliLC2.Location = New System.Drawing.Point(2, 54)
        Me.ButtonCaliLC2.Name = "ButtonCaliLC2"
        Me.ButtonCaliLC2.Size = New System.Drawing.Size(80, 44)
        Me.ButtonCaliLC2.TabIndex = 40
        Me.ButtonCaliLC2.Text = "Calibrate LC2"
        Me.ButtonCaliLC2.UseVisualStyleBackColor = True
        '
        'ButtonCaliLC1
        '
        Me.ButtonCaliLC1.Location = New System.Drawing.Point(2, 4)
        Me.ButtonCaliLC1.Name = "ButtonCaliLC1"
        Me.ButtonCaliLC1.Size = New System.Drawing.Size(80, 44)
        Me.ButtonCaliLC1.TabIndex = 39
        Me.ButtonCaliLC1.Text = "Calibrate LC1"
        Me.ButtonCaliLC1.UseVisualStyleBackColor = True
        '
        'TextBoxCaliDelay
        '
        Me.TextBoxCaliDelay.Location = New System.Drawing.Point(144, 77)
        Me.TextBoxCaliDelay.Name = "TextBoxCaliDelay"
        Me.TextBoxCaliDelay.Size = New System.Drawing.Size(32, 20)
        Me.TextBoxCaliDelay.TabIndex = 38
        Me.TextBoxCaliDelay.Text = "100"
        '
        'TextBoxCaliSteps
        '
        Me.TextBoxCaliSteps.Location = New System.Drawing.Point(144, 53)
        Me.TextBoxCaliSteps.Name = "TextBoxCaliSteps"
        Me.TextBoxCaliSteps.Size = New System.Drawing.Size(32, 20)
        Me.TextBoxCaliSteps.TabIndex = 37
        Me.TextBoxCaliSteps.Text = "700"
        '
        'TextBoxCaliEnd
        '
        Me.TextBoxCaliEnd.Location = New System.Drawing.Point(144, 29)
        Me.TextBoxCaliEnd.Name = "TextBoxCaliEnd"
        Me.TextBoxCaliEnd.Size = New System.Drawing.Size(32, 20)
        Me.TextBoxCaliEnd.TabIndex = 36
        Me.TextBoxCaliEnd.Text = "8.8"
        '
        'TextBoxCaliStart
        '
        Me.TextBoxCaliStart.Location = New System.Drawing.Point(144, 4)
        Me.TextBoxCaliStart.Name = "TextBoxCaliStart"
        Me.TextBoxCaliStart.Size = New System.Drawing.Size(32, 20)
        Me.TextBoxCaliStart.TabIndex = 35
        Me.TextBoxCaliStart.Text = "1.8"
        '
        'CheckBoxCamTrigger
        '
        Me.CheckBoxCamTrigger.AutoSize = True
        Me.CheckBoxCamTrigger.Location = New System.Drawing.Point(183, 9)
        Me.CheckBoxCamTrigger.Name = "CheckBoxCamTrigger"
        Me.CheckBoxCamTrigger.Size = New System.Drawing.Size(78, 17)
        Me.CheckBoxCamTrigger.TabIndex = 28
        Me.CheckBoxCamTrigger.Text = "cam trigger"
        Me.CheckBoxCamTrigger.UseVisualStyleBackColor = True
        '
        'OnTargetCheck
        '
        Me.OnTargetCheck.AutoSize = True
        Me.OnTargetCheck.Location = New System.Drawing.Point(92, 37)
        Me.OnTargetCheck.Name = "OnTargetCheck"
        Me.OnTargetCheck.Size = New System.Drawing.Size(68, 17)
        Me.OnTargetCheck.TabIndex = 27
        Me.OnTargetCheck.Text = "on target"
        Me.OnTargetCheck.UseVisualStyleBackColor = True
        '
        'averageText
        '
        Me.averageText.Location = New System.Drawing.Point(68, 6)
        Me.averageText.Name = "averageText"
        Me.averageText.Size = New System.Drawing.Size(37, 20)
        Me.averageText.TabIndex = 25
        Me.averageText.Text = "100"
        Me.averageText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(111, 9)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(43, 13)
        Me.Label15.TabIndex = 24
        Me.Label15.Text = "avg. pd"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'stopButton
        '
        Me.stopButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.stopButton.Enabled = False
        Me.stopButton.ForeColor = System.Drawing.Color.Maroon
        Me.stopButton.Location = New System.Drawing.Point(399, 92)
        Me.stopButton.Name = "stopButton"
        Me.stopButton.Size = New System.Drawing.Size(60, 50)
        Me.stopButton.TabIndex = 23
        Me.stopButton.Text = "stop"
        Me.stopButton.UseVisualStyleBackColor = True
        '
        'measureButton
        '
        Me.measureButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.measureButton.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.measureButton.ForeColor = System.Drawing.Color.Maroon
        Me.measureButton.Location = New System.Drawing.Point(2, 4)
        Me.measureButton.Name = "measureButton"
        Me.measureButton.Size = New System.Drawing.Size(60, 70)
        Me.measureButton.TabIndex = 0
        Me.measureButton.Text = "start measurement"
        Me.measureButton.UseVisualStyleBackColor = True
        '
        'interruptButton
        '
        Me.interruptButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.interruptButton.Enabled = False
        Me.interruptButton.ForeColor = System.Drawing.Color.Maroon
        Me.interruptButton.Location = New System.Drawing.Point(399, 36)
        Me.interruptButton.Name = "interruptButton"
        Me.interruptButton.Size = New System.Drawing.Size(60, 50)
        Me.interruptButton.TabIndex = 2
        Me.interruptButton.Text = "interrupt"
        Me.interruptButton.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.AutoScroll = True
        Me.Panel2.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel2.Controls.Add(Me.PictureBoxMultiview)
        Me.Panel2.Location = New System.Drawing.Point(238, 22)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(200, 200)
        Me.Panel2.TabIndex = 29
        '
        'PictureBoxMultiview
        '
        Me.PictureBoxMultiview.BackColor = System.Drawing.Color.SteelBlue
        Me.PictureBoxMultiview.Location = New System.Drawing.Point(0, 0)
        Me.PictureBoxMultiview.Name = "PictureBoxMultiview"
        Me.PictureBoxMultiview.Size = New System.Drawing.Size(200, 200)
        Me.PictureBoxMultiview.TabIndex = 19
        Me.PictureBoxMultiview.TabStop = False
        '
        'Label_Multiview
        '
        Me.Label_Multiview.AutoSize = True
        Me.Label_Multiview.ForeColor = System.Drawing.Color.Maroon
        Me.Label_Multiview.Location = New System.Drawing.Point(234, 6)
        Me.Label_Multiview.Name = "Label_Multiview"
        Me.Label_Multiview.Size = New System.Drawing.Size(89, 13)
        Me.Label_Multiview.TabIndex = 22
        Me.Label_Multiview.Text = "multiview window"
        '
        'GroupBoxPostprocessing
        '
        Me.GroupBoxPostprocessing.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBoxPostprocessing.Controls.Add(Me.showautocontrastButton)
        Me.GroupBoxPostprocessing.Controls.Add(Me.showcontrastcolorButton)
        Me.GroupBoxPostprocessing.Controls.Add(Me.showreflexcolorButton)
        Me.GroupBoxPostprocessing.Controls.Add(Me.showautocontrastreflexButton)
        Me.GroupBoxPostprocessing.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBoxPostprocessing.Location = New System.Drawing.Point(238, 228)
        Me.GroupBoxPostprocessing.Name = "GroupBoxPostprocessing"
        Me.GroupBoxPostprocessing.Size = New System.Drawing.Size(201, 86)
        Me.GroupBoxPostprocessing.TabIndex = 25
        Me.GroupBoxPostprocessing.TabStop = False
        Me.GroupBoxPostprocessing.Text = "postprocessing"
        '
        'showautocontrastButton
        '
        Me.showautocontrastButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.showautocontrastButton.Location = New System.Drawing.Point(6, 54)
        Me.showautocontrastButton.Name = "showautocontrastButton"
        Me.showautocontrastButton.Size = New System.Drawing.Size(40, 25)
        Me.showautocontrastButton.TabIndex = 34
        Me.showautocontrastButton.Text = "norm"
        Me.showautocontrastButton.UseVisualStyleBackColor = True
        '
        'showcontrastcolorButton
        '
        Me.showcontrastcolorButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.showcontrastcolorButton.Location = New System.Drawing.Point(46, 54)
        Me.showcontrastcolorButton.Name = "showcontrastcolorButton"
        Me.showcontrastcolorButton.Size = New System.Drawing.Size(42, 25)
        Me.showcontrastcolorButton.TabIndex = 33
        Me.showcontrastcolorButton.Text = "color"
        Me.showcontrastcolorButton.UseVisualStyleBackColor = True
        '
        'showreflexcolorButton
        '
        Me.showreflexcolorButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.showreflexcolorButton.Location = New System.Drawing.Point(126, 54)
        Me.showreflexcolorButton.Name = "showreflexcolorButton"
        Me.showreflexcolorButton.Size = New System.Drawing.Size(68, 25)
        Me.showreflexcolorButton.TabIndex = 38
        Me.showreflexcolorButton.Text = "reflexcolor"
        Me.showreflexcolorButton.UseVisualStyleBackColor = True
        '
        'showautocontrastreflexButton
        '
        Me.showautocontrastreflexButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.showautocontrastreflexButton.Location = New System.Drawing.Point(86, 54)
        Me.showautocontrastreflexButton.Name = "showautocontrastreflexButton"
        Me.showautocontrastreflexButton.Size = New System.Drawing.Size(40, 25)
        Me.showautocontrastreflexButton.TabIndex = 37
        Me.showautocontrastreflexButton.Text = "reflex"
        Me.showautocontrastreflexButton.UseVisualStyleBackColor = True
        '
        'GroupBoxMeasuredValues
        '
        Me.GroupBoxMeasuredValues.Controls.Add(Me.Label32)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.Label10)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.Label31)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.reflexionText)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.pdsignalText)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.referenceText)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.normsignalText)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.Label11)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.reflexnormsignalText)
        Me.GroupBoxMeasuredValues.Controls.Add(Me.Label34)
        Me.GroupBoxMeasuredValues.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBoxMeasuredValues.Location = New System.Drawing.Point(7, 228)
        Me.GroupBoxMeasuredValues.Name = "GroupBoxMeasuredValues"
        Me.GroupBoxMeasuredValues.Size = New System.Drawing.Size(201, 86)
        Me.GroupBoxMeasuredValues.TabIndex = 26
        Me.GroupBoxMeasuredValues.TabStop = False
        Me.GroupBoxMeasuredValues.Text = "measured values"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(133, 16)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(52, 13)
        Me.Label32.TabIndex = 108
        Me.Label32.Text = "reference"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(71, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(46, 13)
        Me.Label10.TabIndex = 107
        Me.Label10.Text = "reflexion"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(8, 16)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(64, 13)
        Me.Label31.TabIndex = 106
        Me.Label31.Text = "transmission"
        '
        'reflexionText
        '
        Me.reflexionText.Cursor = System.Windows.Forms.Cursors.No
        Me.reflexionText.Location = New System.Drawing.Point(73, 30)
        Me.reflexionText.Name = "reflexionText"
        Me.reflexionText.ReadOnly = True
        Me.reflexionText.Size = New System.Drawing.Size(58, 20)
        Me.reflexionText.TabIndex = 15
        Me.reflexionText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pdsignalText
        '
        Me.pdsignalText.Cursor = System.Windows.Forms.Cursors.No
        Me.pdsignalText.Location = New System.Drawing.Point(11, 30)
        Me.pdsignalText.Name = "pdsignalText"
        Me.pdsignalText.ReadOnly = True
        Me.pdsignalText.Size = New System.Drawing.Size(58, 20)
        Me.pdsignalText.TabIndex = 9
        Me.pdsignalText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'referenceText
        '
        Me.referenceText.Cursor = System.Windows.Forms.Cursors.No
        Me.referenceText.Location = New System.Drawing.Point(135, 30)
        Me.referenceText.Name = "referenceText"
        Me.referenceText.ReadOnly = True
        Me.referenceText.Size = New System.Drawing.Size(58, 20)
        Me.referenceText.TabIndex = 7
        Me.referenceText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'normsignalText
        '
        Me.normsignalText.Cursor = System.Windows.Forms.Cursors.No
        Me.normsignalText.Location = New System.Drawing.Point(11, 60)
        Me.normsignalText.Name = "normsignalText"
        Me.normsignalText.ReadOnly = True
        Me.normsignalText.Size = New System.Drawing.Size(58, 20)
        Me.normsignalText.TabIndex = 11
        Me.normsignalText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(33, 46)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(16, 17)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "="
        '
        'reflexnormsignalText
        '
        Me.reflexnormsignalText.Cursor = System.Windows.Forms.Cursors.No
        Me.reflexnormsignalText.Location = New System.Drawing.Point(73, 60)
        Me.reflexnormsignalText.Name = "reflexnormsignalText"
        Me.reflexnormsignalText.ReadOnly = True
        Me.reflexnormsignalText.Size = New System.Drawing.Size(58, 20)
        Me.reflexnormsignalText.TabIndex = 17
        Me.reflexnormsignalText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(95, 46)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(16, 17)
        Me.Label34.TabIndex = 18
        Me.Label34.Text = "="
        '
        'ShowSatCheckBox
        '
        Me.ShowSatCheckBox.AutoSize = True
        Me.ShowSatCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ShowSatCheckBox.Checked = True
        Me.ShowSatCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ShowSatCheckBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ShowSatCheckBox.ForeColor = System.Drawing.Color.Maroon
        Me.ShowSatCheckBox.Location = New System.Drawing.Point(108, 4)
        Me.ShowSatCheckBox.Name = "ShowSatCheckBox"
        Me.ShowSatCheckBox.Size = New System.Drawing.Size(100, 17)
        Me.ShowSatCheckBox.TabIndex = 19
        Me.ShowSatCheckBox.Text = "show saturation"
        Me.ShowSatCheckBox.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel1.Controls.Add(Me.PictureBoxPreview)
        Me.Panel1.Location = New System.Drawing.Point(7, 22)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(200, 200)
        Me.Panel1.TabIndex = 28
        '
        'PictureBoxPreview
        '
        Me.PictureBoxPreview.BackColor = System.Drawing.Color.SteelBlue
        Me.PictureBoxPreview.Location = New System.Drawing.Point(0, 0)
        Me.PictureBoxPreview.Name = "PictureBoxPreview"
        Me.PictureBoxPreview.Size = New System.Drawing.Size(200, 200)
        Me.PictureBoxPreview.TabIndex = 18
        Me.PictureBoxPreview.TabStop = False
        '
        'GroupBoxMeasurementResult
        '
        Me.GroupBoxMeasurementResult.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBoxMeasurementResult.Controls.Add(Me.TabControlView)
        Me.GroupBoxMeasurementResult.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBoxMeasurementResult.Location = New System.Drawing.Point(480, 46)
        Me.GroupBoxMeasurementResult.Name = "GroupBoxMeasurementResult"
        Me.GroupBoxMeasurementResult.Size = New System.Drawing.Size(466, 371)
        Me.GroupBoxMeasurementResult.TabIndex = 17
        Me.GroupBoxMeasurementResult.TabStop = False
        Me.GroupBoxMeasurementResult.Text = "measurement results, progress and postprocessing"
        '
        'TabControlView
        '
        Me.TabControlView.Controls.Add(Me.TabPage4)
        Me.TabControlView.Controls.Add(Me.TabPage5)
        Me.TabControlView.Controls.Add(Me.TabPage6)
        Me.TabControlView.Location = New System.Drawing.Point(6, 16)
        Me.TabControlView.Name = "TabControlView"
        Me.TabControlView.SelectedIndex = 0
        Me.TabControlView.Size = New System.Drawing.Size(454, 348)
        Me.TabControlView.TabIndex = 43
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label_Preview)
        Me.TabPage4.Controls.Add(Me.Panel1)
        Me.TabPage4.Controls.Add(Me.Panel2)
        Me.TabPage4.Controls.Add(Me.Label_Multiview)
        Me.TabPage4.Controls.Add(Me.ShowSatCheckBox)
        Me.TabPage4.Controls.Add(Me.GroupBoxPostprocessing)
        Me.TabPage4.Controls.Add(Me.GroupBoxMeasuredValues)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(446, 322)
        Me.TabPage4.TabIndex = 0
        Me.TabPage4.Text = "2D View"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label_Preview
        '
        Me.Label_Preview.AutoSize = True
        Me.Label_Preview.ForeColor = System.Drawing.Color.Maroon
        Me.Label_Preview.Location = New System.Drawing.Point(4, 6)
        Me.Label_Preview.Name = "Label_Preview"
        Me.Label_Preview.Size = New System.Drawing.Size(83, 13)
        Me.Label_Preview.TabIndex = 31
        Me.Label_Preview.Text = "preview window"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.ButtonTransferRefl)
        Me.TabPage5.Controls.Add(Me.ButtonTransferTran)
        Me.TabPage5.Controls.Add(Me.Label49)
        Me.TabPage5.Controls.Add(Me.ButtonFF)
        Me.TabPage5.Controls.Add(Me.Label56)
        Me.TabPage5.Controls.Add(Me.Label58)
        Me.TabPage5.Controls.Add(Me.Label59)
        Me.TabPage5.Controls.Add(Me.Label60)
        Me.TabPage5.Controls.Add(Me.Label55)
        Me.TabPage5.Controls.Add(Me.mouseoverzText)
        Me.TabPage5.Controls.Add(Me.Label50)
        Me.TabPage5.Controls.Add(Me.Label1)
        Me.TabPage5.Controls.Add(Me.finescan_range)
        Me.TabPage5.Controls.Add(Me.Label51)
        Me.TabPage5.Controls.Add(Me.finescan_step)
        Me.TabPage5.Controls.Add(Me.Label52)
        Me.TabPage5.Controls.Add(Me.TextBoxFFcenter)
        Me.TabPage5.Controls.Add(Me.transminText)
        Me.TabPage5.Controls.Add(Me.reflexmaxText)
        Me.TabPage5.Controls.Add(Me.TextBoxFFxpos)
        Me.TabPage5.Controls.Add(Me.TextBoxFFypos)
        Me.TabPage5.Controls.Add(Me.PictureBox_trans)
        Me.TabPage5.Controls.Add(Me.PictureBox_refl)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(446, 322)
        Me.TabPage5.TabIndex = 1
        Me.TabPage5.Text = "Focus Search"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'ButtonTransferRefl
        '
        Me.ButtonTransferRefl.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonTransferRefl.Image = CType(resources.GetObject("ButtonTransferRefl.Image"), System.Drawing.Image)
        Me.ButtonTransferRefl.Location = New System.Drawing.Point(354, 294)
        Me.ButtonTransferRefl.Name = "ButtonTransferRefl"
        Me.ButtonTransferRefl.Size = New System.Drawing.Size(50, 25)
        Me.ButtonTransferRefl.TabIndex = 65
        Me.ButtonTransferRefl.UseVisualStyleBackColor = True
        '
        'ButtonTransferTran
        '
        Me.ButtonTransferTran.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonTransferTran.Image = CType(resources.GetObject("ButtonTransferTran.Image"), System.Drawing.Image)
        Me.ButtonTransferTran.Location = New System.Drawing.Point(300, 294)
        Me.ButtonTransferTran.Name = "ButtonTransferTran"
        Me.ButtonTransferTran.Size = New System.Drawing.Size(50, 25)
        Me.ButtonTransferTran.TabIndex = 64
        Me.ButtonTransferTran.UseVisualStyleBackColor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.BackColor = System.Drawing.Color.SteelBlue
        Me.Label49.ForeColor = System.Drawing.Color.White
        Me.Label49.Location = New System.Drawing.Point(4, 105)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(68, 13)
        Me.Label49.TabIndex = 63
        Me.Label49.Text = "Transmission"
        '
        'ButtonFF
        '
        Me.ButtonFF.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonFF.Location = New System.Drawing.Point(2, 294)
        Me.ButtonFF.Name = "ButtonFF"
        Me.ButtonFF.Size = New System.Drawing.Size(104, 25)
        Me.ButtonFF.TabIndex = 43
        Me.ButtonFF.Text = "find focus"
        Me.ButtonFF.UseVisualStyleBackColor = True
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.ForeColor = System.Drawing.Color.Black
        Me.Label56.Location = New System.Drawing.Point(21, 254)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(14, 13)
        Me.Label56.TabIndex = 58
        Me.Label56.Text = "X"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.ForeColor = System.Drawing.Color.Maroon
        Me.Label58.Location = New System.Drawing.Point(362, 254)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(32, 13)
        Me.Label58.TabIndex = 61
        Me.Label58.Text = "reflex"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.ForeColor = System.Drawing.Color.Maroon
        Me.Label59.Location = New System.Drawing.Point(310, 254)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(30, 13)
        Me.Label59.TabIndex = 60
        Me.Label59.Text = "trans"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.ForeColor = System.Drawing.Color.Black
        Me.Label60.Location = New System.Drawing.Point(75, 254)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(14, 13)
        Me.Label60.TabIndex = 59
        Me.Label60.Text = "Y"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.ForeColor = System.Drawing.Color.Black
        Me.Label55.Location = New System.Drawing.Point(184, 299)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(48, 13)
        Me.Label55.TabIndex = 57
        Me.Label55.Text = "z (hover)"
        '
        'mouseoverzText
        '
        Me.mouseoverzText.Cursor = System.Windows.Forms.Cursors.No
        Me.mouseoverzText.ForeColor = System.Drawing.Color.Maroon
        Me.mouseoverzText.Location = New System.Drawing.Point(232, 296)
        Me.mouseoverzText.Name = "mouseoverzText"
        Me.mouseoverzText.ReadOnly = True
        Me.mouseoverzText.Size = New System.Drawing.Size(50, 20)
        Me.mouseoverzText.TabIndex = 56
        Me.mouseoverzText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.ForeColor = System.Drawing.Color.Black
        Me.Label50.Location = New System.Drawing.Point(228, 253)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(60, 13)
        Me.Label50.TabIndex = 55
        Me.Label50.Text = "scan range"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.SteelBlue
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(4, 135)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "Reflexion"
        '
        'finescan_range
        '
        Me.finescan_range.Location = New System.Drawing.Point(232, 269)
        Me.finescan_range.Name = "finescan_range"
        Me.finescan_range.ReadOnly = True
        Me.finescan_range.Size = New System.Drawing.Size(50, 20)
        Me.finescan_range.TabIndex = 54
        Me.finescan_range.Text = "20"
        Me.finescan_range.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.ForeColor = System.Drawing.Color.Black
        Me.Label51.Location = New System.Drawing.Point(164, 253)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(50, 13)
        Me.Label51.TabIndex = 53
        Me.Label51.Text = "step [nm]"
        '
        'finescan_step
        '
        Me.finescan_step.Location = New System.Drawing.Point(164, 269)
        Me.finescan_step.Name = "finescan_step"
        Me.finescan_step.Size = New System.Drawing.Size(50, 20)
        Me.finescan_step.TabIndex = 52
        Me.finescan_step.Text = "50"
        Me.finescan_step.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.ForeColor = System.Drawing.Color.Black
        Me.Label52.Location = New System.Drawing.Point(106, 253)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(60, 13)
        Me.Label52.TabIndex = 51
        Me.Label52.Text = "center [µm]"
        '
        'TextBoxFFcenter
        '
        Me.TextBoxFFcenter.Location = New System.Drawing.Point(110, 269)
        Me.TextBoxFFcenter.Name = "TextBoxFFcenter"
        Me.TextBoxFFcenter.Size = New System.Drawing.Size(50, 20)
        Me.TextBoxFFcenter.TabIndex = 50
        Me.TextBoxFFcenter.Text = "10"
        Me.TextBoxFFcenter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'transminText
        '
        Me.transminText.Cursor = System.Windows.Forms.Cursors.No
        Me.transminText.Location = New System.Drawing.Point(300, 269)
        Me.transminText.Name = "transminText"
        Me.transminText.ReadOnly = True
        Me.transminText.Size = New System.Drawing.Size(50, 20)
        Me.transminText.TabIndex = 46
        Me.transminText.Text = "10"
        Me.transminText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'reflexmaxText
        '
        Me.reflexmaxText.Cursor = System.Windows.Forms.Cursors.No
        Me.reflexmaxText.Location = New System.Drawing.Point(354, 269)
        Me.reflexmaxText.Name = "reflexmaxText"
        Me.reflexmaxText.ReadOnly = True
        Me.reflexmaxText.Size = New System.Drawing.Size(50, 20)
        Me.reflexmaxText.TabIndex = 47
        Me.reflexmaxText.Text = "10"
        Me.reflexmaxText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxFFxpos
        '
        Me.TextBoxFFxpos.Location = New System.Drawing.Point(2, 269)
        Me.TextBoxFFxpos.Name = "TextBoxFFxpos"
        Me.TextBoxFFxpos.Size = New System.Drawing.Size(50, 20)
        Me.TextBoxFFxpos.TabIndex = 43
        Me.TextBoxFFxpos.Text = "100"
        Me.TextBoxFFxpos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxFFypos
        '
        Me.TextBoxFFypos.Location = New System.Drawing.Point(56, 269)
        Me.TextBoxFFypos.Name = "TextBoxFFypos"
        Me.TextBoxFFypos.Size = New System.Drawing.Size(50, 20)
        Me.TextBoxFFypos.TabIndex = 44
        Me.TextBoxFFypos.Text = "100"
        Me.TextBoxFFypos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PictureBox_trans
        '
        Me.PictureBox_trans.BackColor = System.Drawing.Color.SteelBlue
        Me.PictureBox_trans.Location = New System.Drawing.Point(2, 4)
        Me.PictureBox_trans.Name = "PictureBox_trans"
        Me.PictureBox_trans.Size = New System.Drawing.Size(401, 120)
        Me.PictureBox_trans.TabIndex = 43
        Me.PictureBox_trans.TabStop = False
        '
        'PictureBox_refl
        '
        Me.PictureBox_refl.BackColor = System.Drawing.Color.SteelBlue
        Me.PictureBox_refl.Location = New System.Drawing.Point(2, 130)
        Me.PictureBox_refl.Name = "PictureBox_refl"
        Me.PictureBox_refl.Size = New System.Drawing.Size(401, 120)
        Me.PictureBox_refl.TabIndex = 44
        Me.PictureBox_refl.TabStop = False
        '
        'TabPage6
        '
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(446, 322)
        Me.TabPage6.TabIndex = 2
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'SerialPortPiezo
        '
        Me.SerialPortPiezo.BaudRate = 115200
        Me.SerialPortPiezo.RtsEnable = True
        '
        'GroupBoxPresettings
        '
        Me.GroupBoxPresettings.Controls.Add(Me.SmileyBox)
        Me.GroupBoxPresettings.Controls.Add(Me.Label39)
        Me.GroupBoxPresettings.Controls.Add(Me.TextBoxMeasNo)
        Me.GroupBoxPresettings.Controls.Add(Me.TextBoxSample)
        Me.GroupBoxPresettings.Controls.Add(Me.TextBoxWavelength)
        Me.GroupBoxPresettings.Controls.Add(Me.Label13)
        Me.GroupBoxPresettings.Controls.Add(Me.Label14)
        Me.GroupBoxPresettings.Controls.Add(Me.TextBoxMeasName)
        Me.GroupBoxPresettings.Controls.Add(Me.Label30)
        Me.GroupBoxPresettings.Controls.Add(Me.Label18)
        Me.GroupBoxPresettings.Controls.Add(Me.TextBoxPol)
        Me.GroupBoxPresettings.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBoxPresettings.Location = New System.Drawing.Point(184, 9)
        Me.GroupBoxPresettings.Name = "GroupBoxPresettings"
        Me.GroupBoxPresettings.Size = New System.Drawing.Size(276, 92)
        Me.GroupBoxPresettings.TabIndex = 13
        Me.GroupBoxPresettings.TabStop = False
        Me.GroupBoxPresettings.Text = "presettings"
        '
        'SmileyBox
        '
        Me.SmileyBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SmileyBox.Image = Global.Nanocapture.My.Resources.Resources.Smiley_happy
        Me.SmileyBox.Location = New System.Drawing.Point(220, 15)
        Me.SmileyBox.Name = "SmileyBox"
        Me.SmileyBox.Size = New System.Drawing.Size(25, 25)
        Me.SmileyBox.TabIndex = 19
        Me.SmileyBox.TabStop = False
        '
        'TextBoxWavelength
        '
        Me.TextBoxWavelength.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBoxWavelength.Location = New System.Drawing.Point(75, 42)
        Me.TextBoxWavelength.Name = "TextBoxWavelength"
        Me.TextBoxWavelength.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxWavelength.TabIndex = 102
        Me.TextBoxWavelength.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(8, 45)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(62, 13)
        Me.Label14.TabIndex = 19
        Me.Label14.Text = "wavelength"
        '
        'TextBoxMeasName
        '
        Me.TextBoxMeasName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBoxMeasName.Location = New System.Drawing.Point(75, 18)
        Me.TextBoxMeasName.Name = "TextBoxMeasName"
        Me.TextBoxMeasName.Size = New System.Drawing.Size(123, 20)
        Me.TextBoxMeasName.TabIndex = 101
        Me.TextBoxMeasName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(202, 45)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(60, 13)
        Me.Label30.TabIndex = 21
        Me.Label30.Text = "polarisation"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(8, 21)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(33, 13)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "name"
        '
        'TextBoxPol
        '
        Me.TextBoxPol.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBoxPol.Location = New System.Drawing.Point(138, 42)
        Me.TextBoxPol.Name = "TextBoxPol"
        Me.TextBoxPol.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxPol.TabIndex = 103
        Me.TextBoxPol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBoxCalcScanfield
        '
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label16)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label17)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label27)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label26)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label25)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label24)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.zstepcalc)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.ystepcalc)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.xstepcalc)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.zcalcendText)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.ycalcendText)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.xcalcendText)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.zcalcstartText)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.ycalcstartText)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.xcalcstartText)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label19)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label20)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label21)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label23)
        Me.GroupBoxCalcScanfield.Controls.Add(Me.Label22)
        Me.GroupBoxCalcScanfield.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBoxCalcScanfield.Location = New System.Drawing.Point(6, 9)
        Me.GroupBoxCalcScanfield.Name = "GroupBoxCalcScanfield"
        Me.GroupBoxCalcScanfield.Size = New System.Drawing.Size(174, 92)
        Me.GroupBoxCalcScanfield.TabIndex = 3
        Me.GroupBoxCalcScanfield.TabStop = False
        Me.GroupBoxCalcScanfield.Text = "calculated scanfield"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(116, 69)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(12, 13)
        Me.Label16.TabIndex = 23
        Me.Label16.Text = "/"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(116, 45)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(12, 13)
        Me.Label17.TabIndex = 22
        Me.Label17.Text = "/"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(116, 21)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(12, 13)
        Me.Label27.TabIndex = 21
        Me.Label27.Text = "/"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(65, 69)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(10, 13)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "-"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(65, 45)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(10, 13)
        Me.Label25.TabIndex = 19
        Me.Label25.Text = "-"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(65, 21)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(10, 13)
        Me.Label24.TabIndex = 18
        Me.Label24.Text = "-"
        '
        'zstepcalc
        '
        Me.zstepcalc.Cursor = System.Windows.Forms.Cursors.No
        Me.zstepcalc.Location = New System.Drawing.Point(131, 66)
        Me.zstepcalc.Name = "zstepcalc"
        Me.zstepcalc.ReadOnly = True
        Me.zstepcalc.Size = New System.Drawing.Size(37, 20)
        Me.zstepcalc.TabIndex = 17
        Me.zstepcalc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ystepcalc
        '
        Me.ystepcalc.Cursor = System.Windows.Forms.Cursors.No
        Me.ystepcalc.Location = New System.Drawing.Point(131, 42)
        Me.ystepcalc.Name = "ystepcalc"
        Me.ystepcalc.ReadOnly = True
        Me.ystepcalc.Size = New System.Drawing.Size(37, 20)
        Me.ystepcalc.TabIndex = 16
        Me.ystepcalc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'xstepcalc
        '
        Me.xstepcalc.Cursor = System.Windows.Forms.Cursors.No
        Me.xstepcalc.Location = New System.Drawing.Point(131, 18)
        Me.xstepcalc.Name = "xstepcalc"
        Me.xstepcalc.ReadOnly = True
        Me.xstepcalc.Size = New System.Drawing.Size(37, 20)
        Me.xstepcalc.TabIndex = 15
        Me.xstepcalc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'zcalcendText
        '
        Me.zcalcendText.Cursor = System.Windows.Forms.Cursors.No
        Me.zcalcendText.Location = New System.Drawing.Point(78, 66)
        Me.zcalcendText.Name = "zcalcendText"
        Me.zcalcendText.ReadOnly = True
        Me.zcalcendText.Size = New System.Drawing.Size(37, 20)
        Me.zcalcendText.TabIndex = 14
        Me.zcalcendText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ycalcendText
        '
        Me.ycalcendText.Cursor = System.Windows.Forms.Cursors.No
        Me.ycalcendText.Location = New System.Drawing.Point(78, 42)
        Me.ycalcendText.Name = "ycalcendText"
        Me.ycalcendText.ReadOnly = True
        Me.ycalcendText.Size = New System.Drawing.Size(37, 20)
        Me.ycalcendText.TabIndex = 13
        Me.ycalcendText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'xcalcendText
        '
        Me.xcalcendText.Cursor = System.Windows.Forms.Cursors.No
        Me.xcalcendText.Location = New System.Drawing.Point(78, 18)
        Me.xcalcendText.Name = "xcalcendText"
        Me.xcalcendText.ReadOnly = True
        Me.xcalcendText.Size = New System.Drawing.Size(37, 20)
        Me.xcalcendText.TabIndex = 12
        Me.xcalcendText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'zcalcstartText
        '
        Me.zcalcstartText.Cursor = System.Windows.Forms.Cursors.No
        Me.zcalcstartText.Location = New System.Drawing.Point(25, 66)
        Me.zcalcstartText.Name = "zcalcstartText"
        Me.zcalcstartText.ReadOnly = True
        Me.zcalcstartText.Size = New System.Drawing.Size(37, 20)
        Me.zcalcstartText.TabIndex = 11
        Me.zcalcstartText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ycalcstartText
        '
        Me.ycalcstartText.Cursor = System.Windows.Forms.Cursors.No
        Me.ycalcstartText.Location = New System.Drawing.Point(25, 42)
        Me.ycalcstartText.Name = "ycalcstartText"
        Me.ycalcstartText.ReadOnly = True
        Me.ycalcstartText.Size = New System.Drawing.Size(37, 20)
        Me.ycalcstartText.TabIndex = 10
        Me.ycalcstartText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'xcalcstartText
        '
        Me.xcalcstartText.Cursor = System.Windows.Forms.Cursors.No
        Me.xcalcstartText.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.xcalcstartText.Location = New System.Drawing.Point(25, 18)
        Me.xcalcstartText.Name = "xcalcstartText"
        Me.xcalcstartText.ReadOnly = True
        Me.xcalcstartText.Size = New System.Drawing.Size(37, 20)
        Me.xcalcstartText.TabIndex = 9
        Me.xcalcstartText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(8, 69)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(14, 13)
        Me.Label19.TabIndex = 8
        Me.Label19.Text = "Z"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(8, 45)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(14, 13)
        Me.Label20.TabIndex = 7
        Me.Label20.Text = "Y"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(8, 21)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(14, 13)
        Me.Label21.TabIndex = 6
        Me.Label21.Text = "X"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(-318, 42)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(14, 13)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "Y"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(-318, 18)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(14, 13)
        Me.Label22.TabIndex = 3
        Me.Label22.Text = "X"
        '
        'otherinfosText
        '
        Me.otherinfosText.Cursor = System.Windows.Forms.Cursors.No
        Me.otherinfosText.Location = New System.Drawing.Point(440, 5)
        Me.otherinfosText.Name = "otherinfosText"
        Me.otherinfosText.ReadOnly = True
        Me.otherinfosText.Size = New System.Drawing.Size(1, 20)
        Me.otherinfosText.TabIndex = 23
        Me.otherinfosText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBoxSettingsList
        '
        Me.GroupBoxSettingsList.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBoxSettingsList.Controls.Add(Me.otherinfosText)
        Me.GroupBoxSettingsList.Controls.Add(Me.GroupBoxCalcScanfield)
        Me.GroupBoxSettingsList.Controls.Add(Me.GroupBoxPresettings)
        Me.GroupBoxSettingsList.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBoxSettingsList.Location = New System.Drawing.Point(480, 417)
        Me.GroupBoxSettingsList.Name = "GroupBoxSettingsList"
        Me.GroupBoxSettingsList.Size = New System.Drawing.Size(466, 107)
        Me.GroupBoxSettingsList.TabIndex = 18
        Me.GroupBoxSettingsList.TabStop = False
        '
        'Surv1
        '
        Me.Surv1.BackColor = System.Drawing.SystemColors.Control
        Me.Surv1.Cursor = System.Windows.Forms.Cursors.No
        Me.Surv1.Location = New System.Drawing.Point(480, 22)
        Me.Surv1.Name = "Surv1"
        Me.Surv1.ReadOnly = True
        Me.Surv1.Size = New System.Drawing.Size(66, 20)
        Me.Surv1.TabIndex = 6
        Me.Surv1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Surv2
        '
        Me.Surv2.BackColor = System.Drawing.SystemColors.Control
        Me.Surv2.Cursor = System.Windows.Forms.Cursors.No
        Me.Surv2.Location = New System.Drawing.Point(550, 22)
        Me.Surv2.Name = "Surv2"
        Me.Surv2.ReadOnly = True
        Me.Surv2.Size = New System.Drawing.Size(66, 20)
        Me.Surv2.TabIndex = 19
        Me.Surv2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Surv3
        '
        Me.Surv3.BackColor = System.Drawing.SystemColors.Control
        Me.Surv3.Cursor = System.Windows.Forms.Cursors.No
        Me.Surv3.Location = New System.Drawing.Point(620, 22)
        Me.Surv3.Name = "Surv3"
        Me.Surv3.ReadOnly = True
        Me.Surv3.Size = New System.Drawing.Size(66, 20)
        Me.Surv3.TabIndex = 20
        Me.Surv3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Surv4
        '
        Me.Surv4.BackColor = System.Drawing.SystemColors.Control
        Me.Surv4.Cursor = System.Windows.Forms.Cursors.No
        Me.Surv4.Location = New System.Drawing.Point(690, 22)
        Me.Surv4.Name = "Surv4"
        Me.Surv4.ReadOnly = True
        Me.Surv4.Size = New System.Drawing.Size(66, 20)
        Me.Surv4.TabIndex = 21
        Me.Surv4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxZoom
        '
        Me.TextBoxZoom.BackColor = System.Drawing.SystemColors.Control
        Me.TextBoxZoom.Cursor = System.Windows.Forms.Cursors.No
        Me.TextBoxZoom.Location = New System.Drawing.Point(760, 22)
        Me.TextBoxZoom.Name = "TextBoxZoom"
        Me.TextBoxZoom.ReadOnly = True
        Me.TextBoxZoom.Size = New System.Drawing.Size(36, 20)
        Me.TextBoxZoom.TabIndex = 22
        Me.TextBoxZoom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_zoom
        '
        Me.Label_zoom.AutoSize = True
        Me.Label_zoom.BackColor = System.Drawing.SystemColors.Control
        Me.Label_zoom.ForeColor = System.Drawing.Color.Black
        Me.Label_zoom.Location = New System.Drawing.Point(758, 4)
        Me.Label_zoom.Name = "Label_zoom"
        Me.Label_zoom.Size = New System.Drawing.Size(32, 13)
        Me.Label_zoom.TabIndex = 32
        Me.Label_zoom.Text = "zoom"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(478, 4)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "MaxPdTrans"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(548, 4)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "MinPdTrans"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(618, 4)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 13)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "unused"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(688, 4)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 13)
        Me.Label12.TabIndex = 35
        Me.Label12.Text = "unused"
        '
        'TextBoxTime
        '
        Me.TextBoxTime.BackColor = System.Drawing.SystemColors.Control
        Me.TextBoxTime.Cursor = System.Windows.Forms.Cursors.No
        Me.TextBoxTime.Location = New System.Drawing.Point(800, 22)
        Me.TextBoxTime.Name = "TextBoxTime"
        Me.TextBoxTime.ReadOnly = True
        Me.TextBoxTime.Size = New System.Drawing.Size(36, 20)
        Me.TextBoxTime.TabIndex = 36
        Me.TextBoxTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.SystemColors.Control
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(798, 4)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(26, 13)
        Me.Label28.TabIndex = 37
        Me.Label28.Text = "time"
        '
        'TabControlCommand
        '
        Me.TabControlCommand.Controls.Add(Me.TabPage1)
        Me.TabControlCommand.Controls.Add(Me.TabPage2)
        Me.TabControlCommand.Controls.Add(Me.TabPage3)
        Me.TabControlCommand.Controls.Add(Me.TabPage7)
        Me.TabControlCommand.Location = New System.Drawing.Point(6, 16)
        Me.TabControlCommand.Name = "TabControlCommand"
        Me.TabControlCommand.SelectedIndex = 0
        Me.TabControlCommand.Size = New System.Drawing.Size(388, 126)
        Me.TabControlCommand.TabIndex = 41
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.ButtonRootdirIMG)
        Me.TabPage1.Controls.Add(Me.TextBoxRootdirIMG)
        Me.TabPage1.Controls.Add(Me.CheckBoxImageCheck)
        Me.TabPage1.Controls.Add(Me.measureButton)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.averageText)
        Me.TabPage1.Controls.Add(Me.OnTargetCheck)
        Me.TabPage1.Controls.Add(Me.CheckBoxCamTrigger)
        Me.TabPage1.ForeColor = System.Drawing.Color.Black
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(380, 100)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Measurement"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'ButtonRootdirIMG
        '
        Me.ButtonRootdirIMG.BackgroundImage = CType(resources.GetObject("ButtonRootdirIMG.BackgroundImage"), System.Drawing.Image)
        Me.ButtonRootdirIMG.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ButtonRootdirIMG.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonRootdirIMG.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonRootdirIMG.Location = New System.Drawing.Point(358, 78)
        Me.ButtonRootdirIMG.Name = "ButtonRootdirIMG"
        Me.ButtonRootdirIMG.Size = New System.Drawing.Size(20, 20)
        Me.ButtonRootdirIMG.TabIndex = 42
        Me.ButtonRootdirIMG.UseVisualStyleBackColor = True
        Me.ButtonRootdirIMG.Visible = False
        '
        'TextBoxRootdirIMG
        '
        Me.TextBoxRootdirIMG.BackColor = System.Drawing.SystemColors.Control
        Me.TextBoxRootdirIMG.Cursor = System.Windows.Forms.Cursors.No
        Me.TextBoxRootdirIMG.Location = New System.Drawing.Point(2, 78)
        Me.TextBoxRootdirIMG.Name = "TextBoxRootdirIMG"
        Me.TextBoxRootdirIMG.ReadOnly = True
        Me.TextBoxRootdirIMG.Size = New System.Drawing.Size(352, 20)
        Me.TextBoxRootdirIMG.TabIndex = 46
        Me.TextBoxRootdirIMG.Visible = False
        '
        'CheckBoxImageCheck
        '
        Me.CheckBoxImageCheck.AutoSize = True
        Me.CheckBoxImageCheck.Location = New System.Drawing.Point(183, 29)
        Me.CheckBoxImageCheck.Name = "CheckBoxImageCheck"
        Me.CheckBoxImageCheck.Size = New System.Drawing.Size(87, 17)
        Me.CheckBoxImageCheck.TabIndex = 29
        Me.CheckBoxImageCheck.Text = "image check"
        Me.CheckBoxImageCheck.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label45)
        Me.TabPage2.Controls.Add(Me.Label43)
        Me.TabPage2.Controls.Add(Me.Label41)
        Me.TabPage2.Controls.Add(Me.Label42)
        Me.TabPage2.Controls.Add(Me.Label40)
        Me.TabPage2.Controls.Add(Me.Label38)
        Me.TabPage2.Controls.Add(Me.Label44)
        Me.TabPage2.Controls.Add(Me.Label37)
        Me.TabPage2.Controls.Add(Me.MaskedTextBox5)
        Me.TabPage2.Controls.Add(Me.MaskedTextBox6)
        Me.TabPage2.Controls.Add(Me.MaskedTextBox7)
        Me.TabPage2.Controls.Add(Me.MaskedTextBox8)
        Me.TabPage2.Controls.Add(Me.MaskedTextBox1)
        Me.TabPage2.Controls.Add(Me.MaskedTextBox2)
        Me.TabPage2.Controls.Add(Me.MaskedTextBox3)
        Me.TabPage2.Controls.Add(Me.MaskedTextBox4)
        Me.TabPage2.Controls.Add(Me.Label36)
        Me.TabPage2.Controls.Add(Me.Label35)
        Me.TabPage2.Controls.Add(Me.Label33)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.ButtonCaliLC2)
        Me.TabPage2.Controls.Add(Me.ButtonCaliLC1)
        Me.TabPage2.Controls.Add(Me.TextBoxCaliStart)
        Me.TabPage2.Controls.Add(Me.TextBoxCaliDelay)
        Me.TabPage2.Controls.Add(Me.TextBoxCaliEnd)
        Me.TabPage2.Controls.Add(Me.TextBoxCaliSteps)
        Me.TabPage2.Controls.Add(Me.ShapeContainer2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(380, 100)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "NOT WORKING"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.ForeColor = System.Drawing.Color.Black
        Me.Label45.Location = New System.Drawing.Point(188, 32)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(61, 13)
        Me.Label45.TabIndex = 60
        Me.Label45.Text = "retardance:"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.ForeColor = System.Drawing.Color.Maroon
        Me.Label43.Location = New System.Drawing.Point(188, 7)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(47, 13)
        Me.Label43.TabIndex = 59
        Me.Label43.Text = "voltages"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Black
        Me.Label41.Location = New System.Drawing.Point(245, 32)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(31, 14)
        Me.Label41.TabIndex = 57
        Me.Label41.Text = "1/4 λ"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(279, 32)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(31, 14)
        Me.Label42.TabIndex = 58
        Me.Label42.Text = "1/2 λ"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Black
        Me.Label40.Location = New System.Drawing.Point(313, 32)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(31, 14)
        Me.Label40.TabIndex = 56
        Me.Label40.Text = "3/4 λ"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Black
        Me.Label38.Location = New System.Drawing.Point(347, 32)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(34, 14)
        Me.Label38.TabIndex = 55
        Me.Label38.Text = "    1 λ"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.ForeColor = System.Drawing.Color.Black
        Me.Label44.Location = New System.Drawing.Point(188, 80)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(54, 13)
        Me.Label44.TabIndex = 55
        Me.Label44.Text = "LC2 22.5°"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(188, 56)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(54, 13)
        Me.Label37.TabIndex = 53
        Me.Label37.Text = "LC1 45.0°"
        '
        'MaskedTextBox5
        '
        Me.MaskedTextBox5.Location = New System.Drawing.Point(242, 53)
        Me.MaskedTextBox5.Name = "MaskedTextBox5"
        Me.MaskedTextBox5.Size = New System.Drawing.Size(34, 20)
        Me.MaskedTextBox5.TabIndex = 49
        Me.MaskedTextBox5.Text = "2"
        '
        'MaskedTextBox6
        '
        Me.MaskedTextBox6.Location = New System.Drawing.Point(276, 77)
        Me.MaskedTextBox6.Name = "MaskedTextBox6"
        Me.MaskedTextBox6.Size = New System.Drawing.Size(34, 20)
        Me.MaskedTextBox6.TabIndex = 52
        Me.MaskedTextBox6.Text = "2"
        '
        'MaskedTextBox7
        '
        Me.MaskedTextBox7.Location = New System.Drawing.Point(242, 77)
        Me.MaskedTextBox7.Name = "MaskedTextBox7"
        Me.MaskedTextBox7.ReadOnly = True
        Me.MaskedTextBox7.Size = New System.Drawing.Size(34, 20)
        Me.MaskedTextBox7.TabIndex = 50
        '
        'MaskedTextBox8
        '
        Me.MaskedTextBox8.Location = New System.Drawing.Point(276, 53)
        Me.MaskedTextBox8.Name = "MaskedTextBox8"
        Me.MaskedTextBox8.Size = New System.Drawing.Size(34, 20)
        Me.MaskedTextBox8.TabIndex = 51
        Me.MaskedTextBox8.Text = "2"
        '
        'MaskedTextBox1
        '
        Me.MaskedTextBox1.Location = New System.Drawing.Point(344, 53)
        Me.MaskedTextBox1.Name = "MaskedTextBox1"
        Me.MaskedTextBox1.Size = New System.Drawing.Size(34, 20)
        Me.MaskedTextBox1.TabIndex = 45
        Me.MaskedTextBox1.Text = "2"
        '
        'MaskedTextBox2
        '
        Me.MaskedTextBox2.Location = New System.Drawing.Point(344, 77)
        Me.MaskedTextBox2.Name = "MaskedTextBox2"
        Me.MaskedTextBox2.Size = New System.Drawing.Size(34, 20)
        Me.MaskedTextBox2.TabIndex = 48
        Me.MaskedTextBox2.Text = "2"
        '
        'MaskedTextBox3
        '
        Me.MaskedTextBox3.Location = New System.Drawing.Point(310, 53)
        Me.MaskedTextBox3.Name = "MaskedTextBox3"
        Me.MaskedTextBox3.Size = New System.Drawing.Size(34, 20)
        Me.MaskedTextBox3.TabIndex = 46
        Me.MaskedTextBox3.Text = "2"
        '
        'MaskedTextBox4
        '
        Me.MaskedTextBox4.Location = New System.Drawing.Point(310, 77)
        Me.MaskedTextBox4.Name = "MaskedTextBox4"
        Me.MaskedTextBox4.ReadOnly = True
        Me.MaskedTextBox4.Size = New System.Drawing.Size(34, 20)
        Me.MaskedTextBox4.TabIndex = 47
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.ForeColor = System.Drawing.Color.Black
        Me.Label36.Location = New System.Drawing.Point(98, 7)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(43, 13)
        Me.Label36.TabIndex = 44
        Me.Label36.Text = "start [V]"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(99, 56)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(42, 13)
        Me.Label35.TabIndex = 43
        Me.Label35.Text = "steps #"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.ForeColor = System.Drawing.Color.Black
        Me.Label33.Location = New System.Drawing.Point(93, 80)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(48, 13)
        Me.Label33.TabIndex = 42
        Me.Label33.Text = "wait [ms]"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(100, 32)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(41, 13)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "end [V]"
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(3, 3)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape1})
        Me.ShapeContainer2.Size = New System.Drawing.Size(374, 94)
        Me.ShapeContainer2.TabIndex = 54
        Me.ShapeContainer2.TabStop = False
        '
        'LineShape1
        '
        Me.LineShape1.BorderColor = System.Drawing.Color.Maroon
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 180
        Me.LineShape1.X2 = 180
        Me.LineShape1.Y1 = 93
        Me.LineShape1.Y2 = 1
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label48)
        Me.TabPage3.Controls.Add(Me.Label47)
        Me.TabPage3.Controls.Add(Me.Label46)
        Me.TabPage3.Controls.Add(Me.ButtonOffset)
        Me.TabPage3.Controls.Add(Me.TextBoxOffRefe)
        Me.TabPage3.Controls.Add(Me.TextBoxOffRefl)
        Me.TabPage3.Controls.Add(Me.TextBoxOffTran)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(380, 100)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Diode Offset"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.ForeColor = System.Drawing.Color.Black
        Me.Label48.Location = New System.Drawing.Point(90, 43)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(46, 13)
        Me.Label48.TabIndex = 211
        Me.Label48.Text = "reflexion"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.ForeColor = System.Drawing.Color.Black
        Me.Label47.Location = New System.Drawing.Point(90, 67)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(52, 13)
        Me.Label47.TabIndex = 210
        Me.Label47.Text = "reference"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.ForeColor = System.Drawing.Color.Black
        Me.Label46.Location = New System.Drawing.Point(90, 19)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(64, 13)
        Me.Label46.TabIndex = 106
        Me.Label46.Text = "transmission"
        '
        'ButtonOffset
        '
        Me.ButtonOffset.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonOffset.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonOffset.Location = New System.Drawing.Point(222, 16)
        Me.ButtonOffset.Name = "ButtonOffset"
        Me.ButtonOffset.Size = New System.Drawing.Size(68, 68)
        Me.ButtonOffset.TabIndex = 42
        Me.ButtonOffset.Text = "read offset"
        Me.ButtonOffset.UseVisualStyleBackColor = True
        '
        'TextBoxOffRefe
        '
        Me.TextBoxOffRefe.Location = New System.Drawing.Point(157, 64)
        Me.TextBoxOffRefe.Name = "TextBoxOffRefe"
        Me.TextBoxOffRefe.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxOffRefe.TabIndex = 209
        Me.TextBoxOffRefe.Text = "-1"
        Me.TextBoxOffRefe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxOffRefl
        '
        Me.TextBoxOffRefl.Location = New System.Drawing.Point(157, 40)
        Me.TextBoxOffRefl.Name = "TextBoxOffRefl"
        Me.TextBoxOffRefl.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxOffRefl.TabIndex = 208
        Me.TextBoxOffRefl.Text = "-1"
        Me.TextBoxOffRefl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxOffTran
        '
        Me.TextBoxOffTran.Location = New System.Drawing.Point(157, 16)
        Me.TextBoxOffTran.Name = "TextBoxOffTran"
        Me.TextBoxOffTran.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxOffTran.TabIndex = 207
        Me.TextBoxOffTran.Text = "-1"
        Me.TextBoxOffTran.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage7
        '
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(380, 100)
        Me.TabPage7.TabIndex = 3
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.stopButton)
        Me.GroupBox1.Controls.Add(Me.interruptButton)
        Me.GroupBox1.Controls.Add(Me.TabControlCommand)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox1.Location = New System.Drawing.Point(10, 375)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(466, 149)
        Me.GroupBox1.TabIndex = 42
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Command Panel"
        '
        'TextBoxRootdir
        '
        Me.TextBoxRootdir.BackColor = System.Drawing.SystemColors.Control
        Me.TextBoxRootdir.Cursor = System.Windows.Forms.Cursors.No
        Me.TextBoxRootdir.Location = New System.Drawing.Point(10, 22)
        Me.TextBoxRootdir.Name = "TextBoxRootdir"
        Me.TextBoxRootdir.ReadOnly = True
        Me.TextBoxRootdir.Size = New System.Drawing.Size(440, 20)
        Me.TextBoxRootdir.TabIndex = 1
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.BackColor = System.Drawing.SystemColors.Control
        Me.Label62.ForeColor = System.Drawing.Color.Black
        Me.Label62.Location = New System.Drawing.Point(8, 4)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(85, 13)
        Me.Label62.TabIndex = 45
        Me.Label62.Text = "storage directory"
        '
        'GroupBoxPositionEntry
        '
        Me.GroupBoxPositionEntry.Controls.Add(Me.TextBoxMaxStepZ)
        Me.GroupBoxPositionEntry.Controls.Add(Me.Label66)
        Me.GroupBoxPositionEntry.Controls.Add(Me.ListBoxMeasureFields)
        Me.GroupBoxPositionEntry.Controls.Add(Me.previewButton)
        Me.GroupBoxPositionEntry.Controls.Add(Me.calculateButton)
        Me.GroupBoxPositionEntry.Controls.Add(Me.Label7)
        Me.GroupBoxPositionEntry.Controls.Add(Me.Label65)
        Me.GroupBoxPositionEntry.Controls.Add(Me.TextBoxMaxStep)
        Me.GroupBoxPositionEntry.Controls.Add(Me.Label64)
        Me.GroupBoxPositionEntry.Controls.Add(Me.zstepsizeText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.Label63)
        Me.GroupBoxPositionEntry.Controls.Add(Me.zstepText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.zposText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.ystepsizeText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.yposText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.ystepText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.xstepsizeText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.xposText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.xstepText)
        Me.GroupBoxPositionEntry.Controls.Add(Me.Label2)
        Me.GroupBoxPositionEntry.Controls.Add(Me.Label4)
        Me.GroupBoxPositionEntry.Controls.Add(Me.Label3)
        Me.GroupBoxPositionEntry.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBoxPositionEntry.Location = New System.Drawing.Point(10, 170)
        Me.GroupBoxPositionEntry.Name = "GroupBoxPositionEntry"
        Me.GroupBoxPositionEntry.Size = New System.Drawing.Size(466, 106)
        Me.GroupBoxPositionEntry.TabIndex = 2
        Me.GroupBoxPositionEntry.TabStop = False
        Me.GroupBoxPositionEntry.Text = "scanfield"
        '
        'TextBoxMaxStepZ
        '
        Me.TextBoxMaxStepZ.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBoxMaxStepZ.Location = New System.Drawing.Point(217, 80)
        Me.TextBoxMaxStepZ.Name = "TextBoxMaxStepZ"
        Me.TextBoxMaxStepZ.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxMaxStepZ.TabIndex = 28
        Me.TextBoxMaxStepZ.Text = "100"
        Me.TextBoxMaxStepZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.ForeColor = System.Drawing.Color.Black
        Me.Label66.Location = New System.Drawing.Point(383, 16)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(44, 13)
        Me.Label66.TabIndex = 27
        Me.Label66.Text = "defaults"
        '
        'ListBoxMeasureFields
        '
        Me.ListBoxMeasureFields.FormattingEnabled = True
        Me.ListBoxMeasureFields.IntegralHeight = False
        Me.ListBoxMeasureFields.Items.AddRange(New Object() {"whole field", "scan particle", "weak meas 3"})
        Me.ListBoxMeasureFields.Location = New System.Drawing.Point(380, 32)
        Me.ListBoxMeasureFields.Name = "ListBoxMeasureFields"
        Me.ListBoxMeasureFields.Size = New System.Drawing.Size(80, 68)
        Me.ListBoxMeasureFields.TabIndex = 19
        '
        'previewButton
        '
        Me.previewButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.previewButton.Enabled = False
        Me.previewButton.ForeColor = System.Drawing.Color.Maroon
        Me.previewButton.Image = CType(resources.GetObject("previewButton.Image"), System.Drawing.Image)
        Me.previewButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.previewButton.Location = New System.Drawing.Point(282, 68)
        Me.previewButton.Name = "previewButton"
        Me.previewButton.Size = New System.Drawing.Size(93, 32)
        Me.previewButton.TabIndex = 15
        Me.previewButton.Text = "view settings"
        Me.previewButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.previewButton.UseVisualStyleBackColor = True
        '
        'calculateButton
        '
        Me.calculateButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.calculateButton.ForeColor = System.Drawing.Color.Maroon
        Me.calculateButton.Image = CType(resources.GetObject("calculateButton.Image"), System.Drawing.Image)
        Me.calculateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.calculateButton.Location = New System.Drawing.Point(282, 32)
        Me.calculateButton.Name = "calculateButton"
        Me.calculateButton.Size = New System.Drawing.Size(93, 32)
        Me.calculateButton.TabIndex = 14
        Me.calculateButton.Text = "calc scanfield"
        Me.calculateButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.calculateButton.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(222, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 13)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "max step"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.ForeColor = System.Drawing.Color.Black
        Me.Label65.Location = New System.Drawing.Point(159, 16)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(48, 13)
        Me.Label65.TabIndex = 26
        Me.Label65.Text = "size [nm]"
        '
        'TextBoxMaxStep
        '
        Me.TextBoxMaxStep.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBoxMaxStep.Location = New System.Drawing.Point(217, 32)
        Me.TextBoxMaxStep.Name = "TextBoxMaxStep"
        Me.TextBoxMaxStep.Size = New System.Drawing.Size(60, 20)
        Me.TextBoxMaxStep.TabIndex = 23
        Me.TextBoxMaxStep.Text = "1000"
        Me.TextBoxMaxStep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.ForeColor = System.Drawing.Color.Black
        Me.Label64.Location = New System.Drawing.Point(98, 16)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(42, 13)
        Me.Label64.TabIndex = 25
        Me.Label64.Text = "steps #"
        '
        'zstepsizeText
        '
        Me.zstepsizeText.Location = New System.Drawing.Point(153, 80)
        Me.zstepsizeText.Name = "zstepsizeText"
        Me.zstepsizeText.Size = New System.Drawing.Size(60, 20)
        Me.zstepsizeText.TabIndex = 2
        Me.zstepsizeText.Text = "100"
        Me.zstepsizeText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.ForeColor = System.Drawing.Color.Black
        Me.Label63.Location = New System.Drawing.Point(22, 16)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(66, 13)
        Me.Label63.TabIndex = 24
        Me.Label63.Text = "position [µm]"
        '
        'zstepText
        '
        Me.zstepText.Location = New System.Drawing.Point(89, 80)
        Me.zstepText.Name = "zstepText"
        Me.zstepText.Size = New System.Drawing.Size(60, 20)
        Me.zstepText.TabIndex = 2
        Me.zstepText.Text = "0"
        Me.zstepText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'zposText
        '
        Me.zposText.Location = New System.Drawing.Point(25, 80)
        Me.zposText.Name = "zposText"
        Me.zposText.Size = New System.Drawing.Size(60, 20)
        Me.zposText.TabIndex = 2
        Me.zposText.Text = "10"
        Me.zposText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ystepsizeText
        '
        Me.ystepsizeText.Location = New System.Drawing.Point(153, 56)
        Me.ystepsizeText.Name = "ystepsizeText"
        Me.ystepsizeText.Size = New System.Drawing.Size(60, 20)
        Me.ystepsizeText.TabIndex = 1
        Me.ystepsizeText.Text = "100"
        Me.ystepsizeText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'yposText
        '
        Me.yposText.Location = New System.Drawing.Point(25, 56)
        Me.yposText.Name = "yposText"
        Me.yposText.Size = New System.Drawing.Size(60, 20)
        Me.yposText.TabIndex = 1
        Me.yposText.Text = "100"
        Me.yposText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ystepText
        '
        Me.ystepText.Location = New System.Drawing.Point(89, 56)
        Me.ystepText.Name = "ystepText"
        Me.ystepText.Size = New System.Drawing.Size(60, 20)
        Me.ystepText.TabIndex = 1
        Me.ystepText.Text = "20"
        Me.ystepText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'xstepsizeText
        '
        Me.xstepsizeText.Location = New System.Drawing.Point(153, 32)
        Me.xstepsizeText.Name = "xstepsizeText"
        Me.xstepsizeText.Size = New System.Drawing.Size(60, 20)
        Me.xstepsizeText.TabIndex = 0
        Me.xstepsizeText.Text = "100"
        Me.xstepsizeText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'xposText
        '
        Me.xposText.Location = New System.Drawing.Point(25, 32)
        Me.xposText.Name = "xposText"
        Me.xposText.Size = New System.Drawing.Size(60, 20)
        Me.xposText.TabIndex = 0
        Me.xposText.Text = "100"
        Me.xposText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'xstepText
        '
        Me.xstepText.Location = New System.Drawing.Point(89, 32)
        Me.xstepText.Name = "xstepText"
        Me.xstepText.Size = New System.Drawing.Size(60, 20)
        Me.xstepText.TabIndex = 0
        Me.xstepText.Text = "20"
        Me.xstepText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(8, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(14, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "X"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(8, 83)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(14, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Z"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(8, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(14, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Y"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ArcOptixV4Step)
        Me.GroupBox2.Controls.Add(Me.Label61)
        Me.GroupBox2.Controls.Add(Me.Label57)
        Me.GroupBox2.Controls.Add(Me.Label54)
        Me.GroupBox2.Controls.Add(Me.Label53)
        Me.GroupBox2.Controls.Add(Me.ArcOptixV3Step)
        Me.GroupBox2.Controls.Add(Me.ArcOptixV3)
        Me.GroupBox2.Controls.Add(Me.ArcOptixV4)
        Me.GroupBox2.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox2.Location = New System.Drawing.Point(10, 276)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(168, 82)
        Me.GroupBox2.TabIndex = 110
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "LC Driver"
        '
        'ArcOptixV4Step
        '
        Me.ArcOptixV4Step.InterceptArrowKeys = False
        Me.ArcOptixV4Step.Items.Add("1.000")
        Me.ArcOptixV4Step.Items.Add("0.100")
        Me.ArcOptixV4Step.Items.Add("0.010")
        Me.ArcOptixV4Step.Items.Add("0.001")
        Me.ArcOptixV4Step.Location = New System.Drawing.Point(108, 56)
        Me.ArcOptixV4Step.Name = "ArcOptixV4Step"
        Me.ArcOptixV4Step.Size = New System.Drawing.Size(54, 20)
        Me.ArcOptixV4Step.TabIndex = 115
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.ForeColor = System.Drawing.Color.Black
        Me.Label61.Location = New System.Drawing.Point(8, 58)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(31, 13)
        Me.Label61.TabIndex = 114
        Me.Label61.Text = "ch. 4"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.ForeColor = System.Drawing.Color.Black
        Me.Label57.Location = New System.Drawing.Point(8, 35)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(31, 13)
        Me.Label57.TabIndex = 113
        Me.Label57.Text = "ch. 3"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.ForeColor = System.Drawing.Color.Black
        Me.Label54.Location = New System.Drawing.Point(109, 16)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(53, 13)
        Me.Label54.TabIndex = 112
        Me.Label54.Text = "increment"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.ForeColor = System.Drawing.Color.Black
        Me.Label53.Location = New System.Drawing.Point(54, 16)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(42, 13)
        Me.Label53.TabIndex = 24
        Me.Label53.Text = "voltage"
        '
        'ArcOptixV3Step
        '
        Me.ArcOptixV3Step.InterceptArrowKeys = False
        Me.ArcOptixV3Step.Items.Add("1.000")
        Me.ArcOptixV3Step.Items.Add("0.100")
        Me.ArcOptixV3Step.Items.Add("0.010")
        Me.ArcOptixV3Step.Items.Add("0.001")
        Me.ArcOptixV3Step.Location = New System.Drawing.Point(108, 32)
        Me.ArcOptixV3Step.Name = "ArcOptixV3Step"
        Me.ArcOptixV3Step.Size = New System.Drawing.Size(54, 20)
        Me.ArcOptixV3Step.TabIndex = 111
        '
        'ArcOptixV3
        '
        Me.ArcOptixV3.DecimalPlaces = 3
        Me.ArcOptixV3.Location = New System.Drawing.Point(50, 32)
        Me.ArcOptixV3.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.ArcOptixV3.Name = "ArcOptixV3"
        Me.ArcOptixV3.Size = New System.Drawing.Size(54, 20)
        Me.ArcOptixV3.TabIndex = 110
        '
        'ArcOptixV4
        '
        Me.ArcOptixV4.DecimalPlaces = 3
        Me.ArcOptixV4.Location = New System.Drawing.Point(50, 56)
        Me.ArcOptixV4.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.ArcOptixV4.Name = "ArcOptixV4"
        Me.ArcOptixV4.Size = New System.Drawing.Size(54, 20)
        Me.ArcOptixV4.TabIndex = 107
        '
        'ButtonRootdir
        '
        Me.ButtonRootdir.BackgroundImage = CType(resources.GetObject("ButtonRootdir.BackgroundImage"), System.Drawing.Image)
        Me.ButtonRootdir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ButtonRootdir.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonRootdir.ForeColor = System.Drawing.Color.Maroon
        Me.ButtonRootdir.Location = New System.Drawing.Point(455, 22)
        Me.ButtonRootdir.Name = "ButtonRootdir"
        Me.ButtonRootdir.Size = New System.Drawing.Size(20, 20)
        Me.ButtonRootdir.TabIndex = 1
        Me.ButtonRootdir.UseVisualStyleBackColor = True
        '
        'MainWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(952, 573)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ButtonRootdir)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label62)
        Me.Controls.Add(Me.TextBoxRootdir)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBoxPositionEntry)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.TextBoxTime)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label_zoom)
        Me.Controls.Add(Me.TextBoxZoom)
        Me.Controls.Add(Me.Surv4)
        Me.Controls.Add(Me.Surv3)
        Me.Controls.Add(Me.Surv2)
        Me.Controls.Add(Me.Surv1)
        Me.Controls.Add(Me.GroupBoxSettingsList)
        Me.Controls.Add(Me.GroupBoxPosition)
        Me.Controls.Add(Me.GroupBoxMeasurementResult)
        Me.Controls.Add(Me.StatusStrip)
        Me.ForeColor = System.Drawing.Color.Black
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(10000, 10000)
        Me.MinimumSize = New System.Drawing.Size(100, 100)
        Me.Name = "MainWindow"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "NanoCapture"
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.GroupBoxPosition.ResumeLayout(False)
        Me.GroupBoxPosition.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBoxMultiview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxPostprocessing.ResumeLayout(False)
        Me.GroupBoxMeasuredValues.ResumeLayout(False)
        Me.GroupBoxMeasuredValues.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBoxPreview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxMeasurementResult.ResumeLayout(False)
        Me.TabControlView.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.PictureBox_trans, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_refl, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxPresettings.ResumeLayout(False)
        Me.GroupBoxPresettings.PerformLayout()
        CType(Me.SmileyBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxCalcScanfield.ResumeLayout(False)
        Me.GroupBoxCalcScanfield.PerformLayout()
        Me.GroupBoxSettingsList.ResumeLayout(False)
        Me.GroupBoxSettingsList.PerformLayout()
        Me.TabControlCommand.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBoxPositionEntry.ResumeLayout(False)
        Me.GroupBoxPositionEntry.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.ArcOptixV3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ArcOptixV4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents GroupBoxPosition As System.Windows.Forms.GroupBox
    Friend WithEvents ZLabel As System.Windows.Forms.Label
    Friend WithEvents zsearchScroll As System.Windows.Forms.HScrollBar
    Friend WithEvents YLabel As System.Windows.Forms.Label
    Friend WithEvents ysearchScroll As System.Windows.Forms.HScrollBar
    Friend WithEvents XLabel As System.Windows.Forms.Label
    Friend WithEvents xsearchScroll As System.Windows.Forms.HScrollBar
    Friend WithEvents zsearchText As System.Windows.Forms.TextBox
    Friend WithEvents ysearchText As System.Windows.Forms.TextBox
    Friend WithEvents xsearchText As System.Windows.Forms.TextBox
    Friend WithEvents ButtonCopyUp As System.Windows.Forms.Button
    Friend WithEvents measureButton As System.Windows.Forms.Button
    Friend WithEvents interruptButton As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents statusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents stopButton As System.Windows.Forms.Button
    Friend WithEvents TextBoxMeasNo As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents focussearchButton As System.Windows.Forms.Button
    Friend WithEvents PictureBoxMultiview As System.Windows.Forms.PictureBox
    Friend WithEvents Label_Multiview As System.Windows.Forms.Label
    Friend WithEvents GroupBoxPostprocessing As System.Windows.Forms.GroupBox
    Friend WithEvents showreflexcolorButton As System.Windows.Forms.Button
    Friend WithEvents showautocontrastreflexButton As System.Windows.Forms.Button
    Friend WithEvents showautocontrastButton As System.Windows.Forms.Button
    Friend WithEvents showcontrastcolorButton As System.Windows.Forms.Button
    Friend WithEvents GroupBoxMeasuredValues As System.Windows.Forms.GroupBox
    Friend WithEvents reflexionText As System.Windows.Forms.TextBox
    Friend WithEvents pdsignalText As System.Windows.Forms.TextBox
    Friend WithEvents referenceText As System.Windows.Forms.TextBox
    Friend WithEvents normsignalText As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents reflexnormsignalText As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents ShowSatCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents PictureBoxPreview As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBoxMeasurementResult As System.Windows.Forms.GroupBox
    Friend WithEvents averageText As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents SerialPortPiezo As System.IO.Ports.SerialPort
    Friend WithEvents OnTargetCheck As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxCamTrigger As System.Windows.Forms.CheckBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBoxPresettings As System.Windows.Forms.GroupBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBoxPol As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextBoxMeasName As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents GroupBoxCalcScanfield As System.Windows.Forms.GroupBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents zstepcalc As System.Windows.Forms.TextBox
    Friend WithEvents ystepcalc As System.Windows.Forms.TextBox
    Friend WithEvents xstepcalc As System.Windows.Forms.TextBox
    Friend WithEvents zcalcendText As System.Windows.Forms.TextBox
    Friend WithEvents ycalcendText As System.Windows.Forms.TextBox
    Friend WithEvents xcalcendText As System.Windows.Forms.TextBox
    Friend WithEvents zcalcstartText As System.Windows.Forms.TextBox
    Friend WithEvents ycalcstartText As System.Windows.Forms.TextBox
    Friend WithEvents xcalcstartText As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents otherinfosText As System.Windows.Forms.TextBox
    Friend WithEvents GroupBoxSettingsList As System.Windows.Forms.GroupBox
    Friend WithEvents ButtonCaliLC1 As System.Windows.Forms.Button
    Friend WithEvents TextBoxCaliDelay As System.Windows.Forms.MaskedTextBox
    Friend WithEvents TextBoxCaliSteps As System.Windows.Forms.MaskedTextBox
    Friend WithEvents TextBoxCaliEnd As System.Windows.Forms.MaskedTextBox
    Friend WithEvents TextBoxCaliStart As System.Windows.Forms.MaskedTextBox
    Friend WithEvents ButtonCaliLC2 As System.Windows.Forms.Button
    Friend WithEvents Surv1 As System.Windows.Forms.TextBox
    Friend WithEvents Surv2 As System.Windows.Forms.TextBox
    Friend WithEvents Surv3 As System.Windows.Forms.TextBox
    Friend WithEvents Surv4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxZoom As System.Windows.Forms.TextBox
    Friend WithEvents Label_zoom As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBoxWavelength As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxSample As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents SmileyBox As System.Windows.Forms.PictureBox
    Friend WithEvents Label_Preview As System.Windows.Forms.Label
    Friend WithEvents TextBoxTime As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents TabControlCommand As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents MaskedTextBox5 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox6 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox7 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox8 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MaskedTextBox4 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents ShapeContainer2 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TextBoxOffRefe As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxOffRefl As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxOffTran As System.Windows.Forms.TextBox
    Friend WithEvents ButtonOffset As System.Windows.Forms.Button
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox_trans As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_refl As System.Windows.Forms.PictureBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents finescan_range As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents finescan_step As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents TextBoxFFcenter As System.Windows.Forms.TextBox
    Friend WithEvents transminText As System.Windows.Forms.TextBox
    Friend WithEvents reflexmaxText As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxFFxpos As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxFFypos As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents mouseoverzText As System.Windows.Forms.TextBox
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents ToolStripProgressBar As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents ButtonFF As System.Windows.Forms.Button
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxRootdir As System.Windows.Forms.TextBox
    Friend WithEvents CheckBoxImageCheck As System.Windows.Forms.CheckBox
    Friend WithEvents ButtonCopyDown As System.Windows.Forms.Button
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents TextBoxRootdirIMG As System.Windows.Forms.TextBox
    Friend WithEvents ButtonTransferRefl As System.Windows.Forms.Button
    Friend WithEvents ButtonTransferTran As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialogRootdir As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents GroupBoxPositionEntry As System.Windows.Forms.GroupBox
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents ListBoxMeasureFields As System.Windows.Forms.ListBox
    Friend WithEvents previewButton As System.Windows.Forms.Button
    Friend WithEvents calculateButton As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents TextBoxMaxStep As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents zstepsizeText As System.Windows.Forms.TextBox
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents zstepText As System.Windows.Forms.TextBox
    Friend WithEvents zposText As System.Windows.Forms.TextBox
    Friend WithEvents ystepsizeText As System.Windows.Forms.TextBox
    Friend WithEvents yposText As System.Windows.Forms.TextBox
    Friend WithEvents ystepText As System.Windows.Forms.TextBox
    Friend WithEvents xstepsizeText As System.Windows.Forms.TextBox
    Friend WithEvents xposText As System.Windows.Forms.TextBox
    Friend WithEvents xstepText As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ArcOptixV4Step As System.Windows.Forms.DomainUpDown
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents ArcOptixV3Step As System.Windows.Forms.DomainUpDown
    Friend WithEvents ArcOptixV3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents ArcOptixV4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBoxMaxStepZ As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ButtonRootdir As System.Windows.Forms.Button
    Friend WithEvents ButtonRootdirIMG As System.Windows.Forms.Button
    Public WithEvents TabControlView As System.Windows.Forms.TabControl

End Class
