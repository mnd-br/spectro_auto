
Public NotInheritable Class SplashScreen

End Class
