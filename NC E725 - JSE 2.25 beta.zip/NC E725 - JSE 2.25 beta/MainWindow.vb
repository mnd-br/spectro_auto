' --- J�RGS NANOCAPTURE VERSION --- WARNING: I heavily modified the code in various way's and also renamed most variables. No guarantee that it works correctly.

Imports System.Math
Imports System.IO
Imports System.Array
Imports System.Threading
Imports System.Globalization
Imports System.Drawing.Imaging
Imports NationalInstruments.DAQmx ' needed for A/D card
Imports ARCoptix.LCdriver ' needed for ArcOpotix USB power supply for q-plate and liquid crystals

Public Class MainWindow

    Private useAD As Task       'Task generation for A/D card
    Private myTask As Task

    Private analogInReader As AnalogSingleChannelReader     'reads single channel of A/D card
    Private analogInMultiReader As AnalogMultiChannelReader 'reads multiple channels of A/D card
    Private analogOutWriter As AnalogSingleChannelWriter    'writes to single channel of A/D card

    Public ArcoptixLC = New LCdriver
    Dim zoom As Double
    Dim MaxPdTrans As Double
    Dim MinPdTrans As Double
    Dim MaxPdReflex As Double
    Dim MinPdReflex As Double
    Dim PreviewColor(2) As Integer
    Dim MultiviewColor(2) As Integer

    'Variables for measurement field
    Dim xcalcstart As Double
    Dim ycalcstart As Double
    Dim zcalcstart As Double
    Dim xcalcend As Double
    Dim ycalcend As Double
    Dim zcalcend As Double

    'some loop variables
    Dim i, k, m, n, o, p, t As Integer
    Dim ST As Boolean = True ' Variable to control Stop function

    'Current Position in Window
    Dim currentX, currentY As Double

    'Variable for Loops through Scan-Image
    Dim runX, runY, runZ As Integer

    'Variables to move through Scan-Image
    Dim temprunX, temprunY As Integer
    Dim xdrivedistance, ydrivedistance, zdrivedistance As Double
    Dim xdrivedirection, ydrivedirection, zdrivedirection As Double
    Dim xdrive, ydrive, zdrive As Double
    Dim xscrolltemp, yscrolltemp, zscrolltemp As Double
    Dim xsearchTexttmp, ysearchTexttmp, zsearchTexttmp As Double
    Dim scandirection As String = "y"
    Dim interrupt As Integer
    Dim s As Integer = 0 ' controlls if coordinate click is allowed

    'Files for measurement data
    Dim File1 As StreamWriter ' pd
    Dim File2 As StreamWriter ' pdnorm
    Dim File3 As StreamWriter ' pdreflex
    Dim File4 As StreamWriter ' pdnormreflex
    Dim File5 As StreamWriter ' pdref
    Dim File9 As StreamWriter ' html file

    Dim pd(2000, 2000) As Double 'Internal arrays for measurement data
    Dim pdref(2000, 2000) As Double
    Dim pdnorm(2000, 2000) As Double
    Dim pdreflex(2000, 2000) As Double
    Dim pdreflexnorm(2000, 2000) As Double
    Dim f(2000, 2000) As Double 'normalized signal

    Dim PdMin As Double = -10   ' minimum voltage for A/D
    Dim PdMax As Double = 10   ' maximum voltage for A/D 
    Dim PdOffTran As String = -1 ' Default offset values for diodes
    Dim PdOffRefl As String = -1
    Dim PdOffRefe As String = -1

    Dim PdTranSignalDbl As Double 'Variables for signals at each point
    Dim PdRefeSignalDbl As Double
    Dim PdReflSignalDbl As Double

    Dim piezoreturn As String = "" 'on-target state of piezo
    Dim piezoreturn_x As String = "" 'on-target state of piezo
    Dim piezoreturn_y As String = "" 'on-target state of piezo
    Dim piezoreturn_z As String = "" 'on-target state of piezo

    Dim start As Date
    Dim tspan As TimeSpan

    Dim Rootdir As String ' rootfolder where to save data of diodes, protocol and scan images
    Dim RootdirIMG As String ' root folder where to save images

    Dim numberOfFiles_old As Integer
    Dim numberOfFiles_new As Integer

    Dim LC0min As Double
    Dim LC0max As Double
    Dim LC1min As Double
    Dim LC1max As Double
    Dim stepsize As Double
    Dim Nmeas As Double
    Dim TT As Double

    Sub initializePiezo()
        If SerialPortPiezo.IsOpen Then
            SerialPortPiezo.Close()
        End If

        With SerialPortPiezo
            .PortName = "COM1"
            .BaudRate = 115200 '115200 f�r die neueren Controller oder 9600 f�r den alten
            .Parity = IO.Ports.Parity.None
            .DataBits = 8
            .StopBits = IO.Ports.StopBits.One
            .WriteTimeout = -1
            .ReadTimeout = -1
        End With

        SerialPortPiezo.Open()
        'SerialPortPiezo.Write("1SL 1" + Chr(10)) ' Command for E 710 'Switch on the Servo loop
        'SerialPortPiezo.Write("2SL 1" + Chr(10))
        'SerialPortPiezo.Write("3SL 1" + Chr(10))
        SerialPortPiezo.Write("SVO1 1" + Chr(10)) ' Command for E 725 'Switch on the Servo loop
        SerialPortPiezo.Write("SVO2 1" + Chr(10))
        SerialPortPiezo.Write("SVO3 1" + Chr(10))
        SerialPortPiezo.RtsEnable = True
        SerialPortPiezo.DtrEnable = True

    End Sub

    Public Function FuncMax(ByVal Array As Double()) As Double
        Dim largest As Double = Double.MinValue ' Assigns the smallest possible value which can be saved in a double
        For Each element As Double In Array
            largest = Math.Max(largest, element)
        Next
        FuncMax = largest
    End Function

    Public Function FuncMin(ByVal Array As Double()) As Double
        Dim smallest As Double = Double.MaxValue ' Assigns the largest possible value which can be saved in a double
        For Each element As Double In Array
            smallest = Math.Min(smallest, element)
        Next
        FuncMin = smallest
    End Function


    Public Function ArrayMean(ByVal arr As Object) As Double ' if arr isn't an array, the function raises an error
        Dim sum As Double = 0
        Dim value As Double
        Dim count As Long = 0
        Dim index As Long

        For index = LBound(arr) To UBound(arr)
            value = arr(index)
            If IsNumeric(value) Then ' skip over non-numeric values
                If Not IsNothing(value) Then ' skip over empty values, if requested
                    count = count + 1
                    sum = sum + value
                End If
            End If
        Next
        ArrayMean = sum / count

    End Function

    Private Sub ButtonOffsetClick() Handles ButtonOffset.Click
        ' NKTPDLL.registerWriteU8("COM3", 17, 48, 0, -1) ' Switch off RF Signal. Works only with new NKT Laser Source
        MsgBox("Switch off Laser or AOTF!", MessageBoxButtons.OK, "Warning")
        Thread.Sleep(500)
        Call ReadFromAD(1000)
        TextBoxOffTran.Text = Round(PdTranSignalDbl, 4)
        TextBoxOffRefe.Text = Round(PdRefeSignalDbl, 4)
        TextBoxOffRefl.Text = Round(PdReflSignalDbl, 4)
        PdOffTran = Round(PdTranSignalDbl, 4)
        PdOffRefe = Round(PdRefeSignalDbl, 4)
        PdOffRefl = Round(PdReflSignalDbl, 4)
        MsgBox("Switch back on!", MessageBoxButtons.OK, "Warning")
        ' NKTPDLL.registerWriteU8("COM3", 17, 48, 1, -1) ' Switch on RF Signal
    End Sub
    Private Sub TextBoxOffTran_TextChanged(sender As Object, e As EventArgs) Handles TextBoxOffTran.Leave, TextBoxOffRefl.Leave, TextBoxOffRefe.Leave ' This function updates offset values as soon as they are changed manually
        PdOffTran = CDbl(TextBoxOffTran.Text)
        PdOffRefe = CDbl(TextBoxOffRefe.Text)
        PdOffRefl = CDbl(TextBoxOffRefl.Text)
    End Sub

    Public Sub ReadFromAD(ByVal DataPt As Double) 'DataPt determines how many datapoints are taken

        PdTranSignalDbl = 0
        PdRefeSignalDbl = 0
        PdReflSignalDbl = 0

        Application.DoEvents()
        Try
            useAD = New Task() 'Create a virtual channel 'MARKER: momentan wird im code jedesmal ein neuer Task erstellt wenn was geschrieben wird. Ich glaube das das unn�tig ist und nur langsamer. F�r den ArcOptix driver hab ich das entfernt und nur ganz am anfang in der initialisierung den "Kanal" erstellt
            useAD.AIChannels.CreateVoltageChannel("Dev1/ai0,Dev1/ai1,Dev1/ai2", "", AITerminalConfiguration.Nrse, PdMin, PdMax, AIVoltageUnits.Volts) 'Channel 0 1 2 = reference reflection transmission
            useAD.Control(TaskAction.Verify)
            analogInMultiReader = New AnalogMultiChannelReader(useAD.Stream)

        Catch ex As DaqException
            MessageBox.Show(ex.Message)
        End Try

        Dim pds(,) As Double = analogInMultiReader.ReadMultiSample(DataPt)
        useAD.Dispose()

        Dim PdTranSignal(DataPt - 1) As Double
        Dim PdRefeSignal(DataPt - 1) As Double
        Dim PdReflSignal(DataPt - 1) As Double

        For i = 0 To DataPt - 1
            PdTranSignal(i) = pds(1, i)
            PdRefeSignal(i) = pds(0, i)
            PdReflSignal(i) = pds(2, i)
        Next

        PdTranSignalDbl = ArrayMean(PdTranSignal)
        PdRefeSignalDbl = ArrayMean(PdRefeSignal)
        PdReflSignalDbl = ArrayMean(PdReflSignal)

    End Sub


    Private Sub MainWindow_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Text = "NanoCapture JSE - " + SplashScreen.Version.Text

        Dim regDate As Date = Date.Now()
        Dim strDate As String = regDate.ToString("yyyy_MM_dd")

        Dim TEMP As StreamReader = New StreamReader("SaveVar.txt") ' Load latest variables
        Rootdir = TEMP.ReadLine
        RootdirIMG = TEMP.ReadLine
        ArcOptixV3.Value = TEMP.ReadLine : ArcOptixV3Step.Text = TEMP.ReadLine
        ArcOptixV4.Value = TEMP.ReadLine : ArcOptixV4Step.Text = TEMP.ReadLine
        TEMP.Close()

        'Initialization of information values
        TextBoxMeasName.Text = "meas_" + strDate
        TextBoxTime.Text = "" ' This measures how much time the scan takes
        TextBoxRootdir.Text = Rootdir
        TextBoxRootdirIMG.Text = RootdirIMG
        If Dir(Rootdir + "\" + TextBoxMeasName.Text, vbDirectory) <> "" Then ' Checks if the root folder exists
            For Each foundFile As String In My.Computer.FileSystem.GetFiles(Rootdir + "\" + TextBoxMeasName.Text, Microsoft.VisualBasic.FileIO.SearchOption.SearchAllSubDirectories, "*.html")
                TextBoxMeasNo.Text = TextBoxMeasNo.Text + 1 ' This counts the measurements which are already in the root folder
            Next
        End If

        initializePiezo()

        'read piezo position from controller
        'SerialPortPiezo.Write("1TP" + Chr(10)) ' Command for E 710
        SerialPortPiezo.Write("MOV? 1" + Chr(10)) ' Command for E 725
        Thread.Sleep(100)
        piezoreturn_x = SerialPortPiezo.ReadExisting()
        xsearchText.Text = Round(Double.Parse(piezoreturn_x.Remove(0, 2), NumberStyles.Float Or NumberStyles.AllowTrailingSign), 3)
        'SerialPortPiezo.Write("2TP" + Chr(10)) ' Command for E 710
        SerialPortPiezo.Write("MOV? 2" + Chr(10)) ' Command for E 725
        Thread.Sleep(100)
        piezoreturn_y = SerialPortPiezo.ReadExisting()
        ysearchText.Text = Round(Double.Parse(piezoreturn_y.Remove(0, 2), NumberStyles.Float Or NumberStyles.AllowTrailingSign), 3)
        'SerialPortPiezo.Write("3TP" + Chr(10)) ' Command for E 710
        SerialPortPiezo.Write("MOV? 3" + Chr(10)) ' Command for E 725
        Thread.Sleep(100)
        piezoreturn_z = SerialPortPiezo.ReadExisting()
        zsearchText.Text = Round(Double.Parse(piezoreturn_z.Remove(0, 2), NumberStyles.Float Or NumberStyles.AllowTrailingSign), 3)

        interrupt = 0 ' interrupt-variable

        xsearchScroll.Value = xsearchText.Text * 1000 'scrollbars
        ysearchScroll.Value = ysearchText.Text * 1000 'for
        zsearchScroll.Value = zsearchText.Text * 1000 'manual postion search

        AddHandler TextBoxRootdir.TextChanged, AddressOf SaveVariables
        AddHandler TextBoxRootdirIMG.TextChanged, AddressOf SaveVariables
        AddHandler ArcOptixV3.ValueChanged, AddressOf SaveVariables : AddHandler ArcOptixV4.ValueChanged, AddressOf SaveVariables
        AddHandler ArcOptixV3Step.SelectedItemChanged, AddressOf SaveVariables : AddHandler ArcOptixV4Step.SelectedItemChanged, AddressOf SaveVariables

    End Sub

    Private Sub ArcOptixV3_ValueChanged() Handles ArcOptixV3.ValueChanged
        ArcoptixLC.SetDACVoltage(ArcOptixV3.Value, 2)
    End Sub
    Private Sub ArcOptixV4_ValueChanged() Handles ArcOptixV4.ValueChanged
        ArcoptixLC.SetDACVoltage(ArcOptixV4.Value, 3)
    End Sub
    Private Sub ArcOptixV3Step_SelectedItemChanged() Handles ArcOptixV3Step.SelectedItemChanged
        ArcOptixV3.Increment = ArcOptixV3Step.Text
    End Sub
    Private Sub ArcOptixV4Step_SelectedItemChanged() Handles ArcOptixV4Step.SelectedItemChanged
        ArcOptixV4.Increment = ArcOptixV4Step.Text
    End Sub

    Private Sub EnableRottdirIMG() Handles CheckBoxImageCheck.Click
        If CheckBoxImageCheck.Checked = True Then
            TextBoxRootdirIMG.Visible = True
            ButtonRootdirIMG.Visible = True
        Else
            TextBoxRootdirIMG.Visible = False
            ButtonRootdirIMG.Visible = False
        End If
    End Sub

    Private Sub SaveVariables()
        Dim TEMP As StreamWriter = New StreamWriter("SaveVar.txt")
        TEMP.WriteLine(Rootdir)
        TEMP.WriteLine(RootdirIMG)
        TEMP.WriteLine(ArcOptixV3.Value) : TEMP.WriteLine(ArcOptixV3Step.Text)
        TEMP.WriteLine(ArcOptixV4.Value) : TEMP.WriteLine(ArcOptixV4Step.Text)
        TEMP.Close()
    End Sub

    Private Sub ButtonRootdir_Click() Handles ButtonRootdir.Click
        FolderBrowserDialogRootdir.Description = "Select storage directory."
        If FolderBrowserDialogRootdir.ShowDialog() = DialogResult.OK Then
            Rootdir = FolderBrowserDialogRootdir.SelectedPath
            TextBoxRootdir.Text = FolderBrowserDialogRootdir.SelectedPath
        End If
    End Sub
    Private Sub ButtonRootdirIMG_Click() Handles ButtonRootdirIMG.Click
        FolderBrowserDialogRootdir.Description = "Select storage directory for images."
        If FolderBrowserDialogRootdir.ShowDialog() = DialogResult.OK Then
            RootdirIMG = FolderBrowserDialogRootdir.SelectedPath
            TextBoxRootdirIMG.Text = FolderBrowserDialogRootdir.SelectedPath
        End If
    End Sub


    Sub MoveAbsoluteX(ByVal xPos As Double) ' moves x-axis to xPos slowly, speed depends on distance.

        xscrolltemp = xsearchScroll.Value / 1000 ' temporary variable, stores current position [�m]
        xdrivedistance = Abs(xPos - xscrolltemp) ' distance in x-direction that has to be driven 
        xdrivedirection = Sign(xPos - xscrolltemp) ' direction in which has to be driven (+-1)
        If xdrivedistance > TextBoxMaxStep.Text / 1000 Then ' If distance large then move in small increments
            For xdrive = xscrolltemp To xPos Step TextBoxMaxStep.Text / 1000 * xdrivedirection
                'SerialPortPiezo.Write("1ma0" + Str$(xdrive) + Chr(10)) ' Command for E 710
                SerialPortPiezo.Write("MOV 1" + Str$(xdrive) + Chr(10)) ' Command for E 725
                xsearchScroll.Value = xdrive * 1000
                xsearchText.Text = xdrive
                Application.DoEvents()
            Next xdrive
        End If
        'SerialPortPiezo.Write("1ma0" + Str$(xPos) + Chr(10)) ' Move residual part 
        SerialPortPiezo.Write("MOV 1" + Str$(xPos) + Chr(10)) ' Move residual part 
        xsearchScroll.Value = xPos * 1000
        xsearchText.Text = xPos

    End Sub

    Sub MoveAbsoluteY(ByVal yPos As Double) ' moves y-axis to yPos slowly, speed depends on distance.

        yscrolltemp = ysearchScroll.Value / 1000 ' temporary variable, stores current position [�m]
        ydrivedistance = Abs(yPos - yscrolltemp) ' distance in y-direction that has to be driven 
        ydrivedirection = Sign(yPos - yscrolltemp) ' direction in which has to be driven (+-1)
        If ydrivedistance > TextBoxMaxStep.Text / 1000 Then ' If distance large then move in small increments
            For ydrive = yscrolltemp To yPos Step TextBoxMaxStep.Text / 1000 * ydrivedirection
                'SerialPortPiezo.Write("2ma0" + Str$(ydrive) + Chr(10)) ' Command for E 710
                SerialPortPiezo.Write("MOV 2" + Str$(xdrive) + Chr(10)) ' Command for E 725
                ysearchScroll.Value = ydrive * 1000
                ysearchText.Text = ydrive
                Application.DoEvents()
            Next ydrive
        End If
        'SerialPortPiezo.Write("2ma0" + Str$(yPos) + Chr(10)) ' Move residual part 
        SerialPortPiezo.Write("MOV 2" + Str$(yPos) + Chr(10)) ' Move residual part 
        ysearchScroll.Value = yPos * 1000
        ysearchText.Text = yPos

    End Sub

    Sub MoveAbsoluteZ(ByVal zPos As Double) ' moves z-axis to zPos slowly, speed depends on distance.

        zscrolltemp = zsearchScroll.Value / 1000 ' temporary variable, stores current position [�m]
        zdrivedistance = Abs(zPos - zscrolltemp) ' distance in z-direction that has to be driven 
        zdrivedirection = Sign(zPos - zscrolltemp) ' direction in which has to be driven (+-1)
        If zdrivedistance > TextBoxMaxStepZ.Text / 1000 Then ' If distance large then move in small increments. z-axis has even smaller steps than x and y (factor 10)
            For zdrive = zscrolltemp To zPos Step TextBoxMaxStepZ.Text / 1000 * zdrivedirection
                'SerialPortPiezo.Write("3ma0" + Str$(zdrive) + Chr(10)) ' Command for E 710
                SerialPortPiezo.Write("MOV 3 " + Str$(xdrive) + Chr(10)) ' Command for E 725
                zsearchScroll.Value = zdrive * 1000
                zsearchText.Text = zdrive
                Application.DoEvents()
            Next zdrive
        End If
        'SerialPortPiezo.Write("3ma0" + Str$(zPos) + Chr(10)) ' Move residual part
        SerialPortPiezo.Write("MOV 3" + Str$(zPos) + Chr(10)) ' Move residual part 
        zsearchScroll.Value = zPos * 1000
        zsearchText.Text = zPos

    End Sub

    Private Sub xsearchScroll_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles xsearchScroll.Scroll
        initializePiezo()
        MoveAbsoluteX(CDbl(xsearchScroll.Value / 1000))
    End Sub

    Private Sub ysearchScroll_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles ysearchScroll.Scroll
        initializePiezo()
        MoveAbsoluteY(CDbl(ysearchScroll.Value / 1000))
    End Sub

    Private Sub zsearchScroll_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles zsearchScroll.Scroll
        initializePiezo()
        MoveAbsoluteZ(CDbl(zsearchScroll.Value / 1000))
    End Sub

    Private Sub xsearchtext_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles xsearchText.KeyPress
        initializePiezo()
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8, 32, 46 ' Allow numbers 0-9, backspace, space and dot
            Case 13 ' Allow enter
                If Val(xsearchText.Text) > 200 Then xsearchText.Text = 200
                MoveAbsoluteX(CDbl(xsearchText.Text))
            Case Else ' suppress all other keys
                e.Handled = True
        End Select
    End Sub

    Private Sub ysearchtext_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ysearchText.KeyPress
        initializePiezo()
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8, 32, 46 ' Allow numbers 0-9, backspace, space and dot
            Case 13 ' Allow enter
                If Val(ysearchText.Text) > 200 Then ysearchText.Text = 200
                MoveAbsoluteY(CDbl(ysearchText.Text))
            Case Else ' suppress all other keys
                e.Handled = True
        End Select
    End Sub

    Private Sub zsearchtext_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles zsearchText.KeyPress
        initializePiezo()
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8, 32, 46 ' Allow numbers 0-9, backspace, space and dot
            Case 13 ' Allow enter
                If Val(zsearchText.Text) > 20 Then zsearchText.Text = 20
                MoveAbsoluteZ(CDbl(zsearchText.Text))
            Case Else ' suppress all other keys
                e.Handled = True
        End Select
    End Sub

    Private Sub xpostext_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles xposText.KeyPress, yposText.KeyPress, zposText.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8, 32, 46 ' Allow numbers 0-9, backspace, space and dot
            Case Else ' suppress all other keys
                e.Handled = True
        End Select
    End Sub

    Private Sub ButtonCopyDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCopyDown.Click
        xposText.Text = xsearchText.Text
        yposText.Text = ysearchText.Text
        zposText.Text = zsearchText.Text
    End Sub

    Private Sub ButtonCopyUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCopyUp.Click
        MoveAbsoluteX(xposText.Text)
        MoveAbsoluteY(yposText.Text)
        MoveAbsoluteZ(zposText.Text)
    End Sub

    Private Sub calculateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles calculateButton.Click
        Call calculateScanfield()
        zoom = Max(Min(Floor(200 / xstepcalc.Text), Floor(200 / ystepcalc.Text)), 1) ' berechnet kleinstes Vielfaches der Scangr��e welches noch in das 200x200 Px Fenster passt. Falls Scan gr��er als Fenster dann Zoom=1
        TextBoxZoom.Text = zoom
    End Sub

    Private Sub calculateScanfield()

        previewButton.Enabled = True

        xcalcstart = CDbl(xposText.Text - (xstepText.Text * xstepsizeText.Text) / 1000)
        ycalcstart = CDbl(yposText.Text - (ystepText.Text * ystepsizeText.Text) / 1000)
        zcalcstart = CDbl(zposText.Text - (zstepText.Text * zstepsizeText.Text) / 1000)
        xcalcend = CDbl(xposText.Text + (xstepText.Text * xstepsizeText.Text) / 1000)
        ycalcend = CDbl(yposText.Text + (ystepText.Text * ystepsizeText.Text) / 1000)
        zcalcend = CDbl(zposText.Text + (zstepText.Text * zstepsizeText.Text) / 1000)
        xstepcalc.Text = xstepText.Text * 2 + 1
        ystepcalc.Text = ystepText.Text * 2 + 1
        zstepcalc.Text = zstepText.Text * 2 + 1

        'test for valid values. range > 0 or < 200 (20)?-------------------------------------------------
        If xcalcstart < 0 Or xcalcend > 200 Or ycalcstart < 0 Or ycalcend > 200 Or zcalcstart < 0 Or zcalcend > 20 Then
            MsgBox("One or more calculated values of the scanfield are out of range!", MessageBoxButtons.OK, "Warning")
        Else
            xcalcstartText.Text = xcalcstart
            ycalcstartText.Text = ycalcstart
            zcalcstartText.Text = zcalcstart
            xcalcendText.Text = xcalcend
            ycalcendText.Text = ycalcend
            zcalcendText.Text = zcalcend
        End If

    End Sub

    Private Sub previewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles previewButton.Click ' creates message box with overview of settings

        MsgBox("measurement presettings: " & Chr(10) _
               & "name: " & TextBoxMeasName.Text & Chr(10) _
               & "structure: " & TextBoxSample.Text & Chr(10) _
               & "wavelength: " & TextBoxWavelength.Text & Chr(10) _
               & "polarisation: " & TextBoxPol.Text & Chr(10) _
               & "scan direction: " & scandirection & Chr(10) _
               & Chr(10) _
               & "position: " & Chr(10) _
               & "x: " & xposText.Text & Chr(10) _
               & "y: " & yposText.Text & Chr(10) _
               & "z: " & zposText.Text & Chr(10) & Chr(10) _
               & "stepsize * steps: " & Chr(10) _
               & "x: " & xstepsizeText.Text & " * " & xstepcalc.Text & Chr(10) _
               & "y: " & ystepsizeText.Text & " * " & ystepcalc.Text & Chr(10) _
               & "z: " & zstepsizeText.Text & " * " & zstepcalc.Text & Chr(10) _
               & Chr(10) _
               & "scanfield: " & Chr(10) _
               & "x: " & xcalcstartText.Text & " to " & xcalcendText.Text & Chr(10) _
               & "y: " & ycalcstartText.Text & " to " & ycalcendText.Text & Chr(10) _
               & "z: " & zcalcstartText.Text & " to " & zcalcendText.Text, MsgBoxStyle.OkOnly, "preview of measurement settings")

    End Sub

    Private Sub PictureBoxPreview_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBoxPreview.MouseMove

        Dim pt As Point = PictureBoxPreview.PointToClient(Control.MousePosition) ' read out which pixel was clickt. First pixel gives 0,0
        currentX = pt.X
        currentY = pt.Y

    End Sub

    Private Sub PictureBoxPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBoxPreview.Click

        If xcalcstartText.Text <> "" And s = 1 Then
            xposText.Text = Round(xcalcendText.Text - Floor(currentX.ToString / zoom) * (xstepsizeText.Text / 1000), 3)
            yposText.Text = Round(ycalcstartText.Text + Floor(currentY.ToString / zoom) * (ystepsizeText.Text / 1000), 3)
        End If

    End Sub

    Private Sub PictureBoxMultiview_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBoxMultiview.MouseMove

        Dim pt As Point = PictureBoxMultiview.PointToClient(Control.MousePosition)
        currentX = pt.X
        currentY = pt.Y

    End Sub

    Private Sub PictureBoxMultiview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBoxMultiview.Click

        If xcalcstartText.Text <> "" And s = 1 Then
            xposText.Text = Round(xcalcendText.Text - Floor(currentX.ToString / zoom) * (xstepsizeText.Text / 1000), 3)
            yposText.Text = Round(ycalcstartText.Text + Floor(currentY.ToString / zoom) * (ystepsizeText.Text / 1000), 3)
        End If

    End Sub

    Private Sub ListBoxMeasureFields_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBoxMeasureFields.SelectedIndexChanged

        If ListBoxMeasureFields.Text = "whole field" Then
            xposText.Text = 100
            yposText.Text = 100
            xstepText.Text = 20
            ystepText.Text = 20
            xstepsizeText.Text = 5000
            ystepsizeText.Text = 5000
        End If
        If ListBoxMeasureFields.Text = "scan particle" Then
            xstepText.Text = 16
            ystepText.Text = 16
            xstepsizeText.Text = 60
            ystepsizeText.Text = 60
        End If
        If ListBoxMeasureFields.Text = "weak meas 3" Then
            xstepText.Text = 20
            ystepText.Text = 20
            xstepsizeText.Text = 5
            ystepsizeText.Text = 5
        End If

    End Sub

    Sub counter()
        tspan = DateTime.Now.Subtract(start)
        TextBoxTime.Text = tspan.Minutes & ":" & tspan.Seconds
    End Sub

    'measurement start--------------------------------------------------->>

    Private Sub measureButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles measureButton.Click

        start = DateTime.Now
        Call counter()

        If xcalcstartText.Text <> "" Or zstepcalc.Text <> "" Then ' check if a scanfield was calculated
            interruptButton.Enabled = True : stopButton.Enabled = True
            measureButton.Enabled = False : calculateButton.Enabled = False
            TabControlView.SelectedIndex = 0 ' Change to Tab 1 of the view panel
            Call measurement()
        Else
            MsgBox("Please define a scanfield first!", MsgBoxStyle.OkOnly, "Warning!")
        End If

    End Sub

    Private Sub measurement()

        Call counter()
        ToolStripProgressBar.Maximum = Convert.ToInt32(xstepcalc.Text)
        i = 0
        ST = True
        t = CInt(averageText.Text)
        MaxPdTrans = Double.MinValue
        MinPdTrans = Double.MaxValue
        MaxPdReflex = Double.MinValue
        MinPdReflex = Double.MaxValue
        Dim Temp As Integer
        statusLabel.Text = "measurement is running..."
        PictureBoxPreview.Width = xstepcalc.Text * zoom
        PictureBoxPreview.Height = ystepcalc.Text * zoom
        Dim dir As IO.DirectoryInfo = IO.Directory.CreateDirectory(Rootdir + "\" + TextBoxMeasName.Text)
        Dim drawingPreview As New Bitmap(PictureBoxPreview.Width, PictureBoxPreview.Height)
        Dim drawingMultiview As New Bitmap(PictureBoxMultiview.Width, PictureBoxMultiview.Height)
        Dim graphPreview As Graphics
        Dim graphMultiview As Graphics
        Dim pen1 As New Pen(Color.White, 1)
        Dim pen2 As New Pen(Color.Black, 1)
        graphMultiview = Graphics.FromImage(drawingMultiview)
        graphMultiview.Clear(Color.SteelBlue)
        graphPreview = Graphics.FromImage(drawingPreview)
        graphPreview.Clear(Color.SteelBlue)
        numberOfFiles_old = System.IO.Directory.GetFiles(RootdirIMG + "\").Length - 1

        initializePiezo()

        MoveAbsoluteX(CDbl(xcalcstartText.Text))
        MoveAbsoluteY(CDbl(ycalcendText.Text))
        MoveAbsoluteZ(CDbl(zcalcstartText.Text))

        Thread.Sleep(100) 'additional time to settle piezo

        runZ = 0
        runX = 0
        runY = 0

        'start piezomovement------------------------------->>
        For runZ = 0 To Convert.ToInt32(zstepcalc.Text - 1) Step 1

            ToolStripProgressBar.Value = 0
            statusLabel.Text = "measurement " & (runZ + 1) & " of " & zstepcalc.Text & " is running..."
            zsearchScroll.Value = zcalcstartText.Text * 1000 + runZ * zstepsizeText.Text
            zsearchText.Text = zsearchScroll.Value / 1000

            'reset all data arrays
            graphPreview = Graphics.FromImage(drawingPreview)
            graphPreview.Clear(Color.SteelBlue)
            graphMultiview = Graphics.FromImage(drawingMultiview)
            graphMultiview.Clear(Color.SteelBlue)

            Array.Clear(pd, 0, 4000000)
            Array.Clear(pdnorm, 0, 4000000)

            Array.Clear(pdref, 0, 4000000)

            Array.Clear(pdreflex, 0, 4000000)
            Array.Clear(pdreflexnorm, 0, 4000000)

            Try
                useAD = New Task()
                useAD.AIChannels.CreateVoltageChannel("Dev1/ai7,Dev1/ai1,Dev1/ai4", "", AITerminalConfiguration.Nrse, PdMin, PdMax, AIVoltageUnits.Volts)
                useAD.Control(TaskAction.Verify)
                analogInMultiReader = New AnalogMultiChannelReader(useAD.Stream)
                '#If NETFX2_0 Then ' MARKER: NET Framework 2.0 war glaube ich zu Jesus Zeiten schon veraltet ... habs mal auskommentiert
                '                    ' For .NET Framework 2.0, use SynchronizeCallbacks to specify that the object 
                '                    ' marshals callbacks across threads appropriately.
                '                    analogInReader.SynchronizeCallbacks = True
                '#End If
            Catch ex As DaqException
                MessageBox.Show(ex.Message)
            End Try
            Dim pds(,) As Double = analogInMultiReader.ReadMultiSample(t)


            For runX = 0 To xstepcalc.Text - 1 Step 1

                xsearchScroll.Value = xcalcstartText.Text * 1000 + (runX) * xstepsizeText.Text
                xsearchText.Text = xsearchScroll.Value / 1000

                For runY = Convert.ToInt32(ystepcalc.Text - 1) To 0 Step -1

                    Call counter()

                    If ST = False Then
                        Exit Sub
                    End If

                    ysearchScroll.Value = ycalcstartText.Text * 1000 + runY * ystepsizeText.Text
                    ysearchText.Text = ysearchScroll.Value / 1000

                    'SerialPortPiezo.Write("1ma0" + Str$(xsearchScroll.Value / 1000) + ",2ma0" + Str$(ysearchScroll.Value / 1000) + ",3ma0" + Str$(zsearchScroll.Value / 1000) + Chr(10)) ' Command for E 710
                    SerialPortPiezo.Write("MOV 1 " + Str$(xsearchScroll.Value / 1000) + " 2 " + Str$(ysearchScroll.Value / 1000) + " 3 " + Str$(zsearchScroll.Value / 1000) + Chr(10)) ' Command for E 725

                    If OnTargetCheck.Checked = True Then
                        Thread.Sleep(12) ' Timeout to achieve settling of piezo --> leads to 15ms until Pd readout --> optimum for d<1�m
                    End If
                    If runY = ystepcalc.Text - 1 Then
                        Thread.Sleep(200)
                    End If


                    If CheckBoxCamTrigger.Checked = True Then
                        If CheckBoxImageCheck.Checked = True Then ' This part checks if an image was created. If not the code is in an endless loop till there is a new file in the folder
                            numberOfFiles_new = System.IO.Directory.GetFiles(RootdirIMG + "\").Length
                            While numberOfFiles_new = numberOfFiles_old
                                Thread.Sleep(1)
                                numberOfFiles_new = System.IO.Directory.GetFiles(RootdirIMG + "\").Length
                                Application.DoEvents() ' MARKER: kann sein das das hier die Schleife verlangsamt aber ich weis nicht wie man die Messung sonst abbrechen soll wenn keine Bilder erstellt werden
                                If ST = False Then
                                    Exit Sub
                                End If
                            End While
                            numberOfFiles_old = numberOfFiles_new
                        End If

                        Try
                            myTask = New Task()
                            myTask.AOChannels.CreateVoltageChannel("Dev1/ao1", "", PdMin, PdMax, AOVoltageUnits.Volts)

                            Dim writer As AnalogSingleChannelWriter = New AnalogSingleChannelWriter(myTask.Stream)

                            writer.WriteSingleSample(True, Convert.ToDouble(5)) 'Trigger Signal for camera
                            Thread.Sleep(1)
                            writer.WriteSingleSample(True, Convert.ToDouble(0))
                        Catch ex As DaqException
                            MessageBox.Show(ex.Message)
                        Finally
                            myTask.Dispose()
                        End Try

                        Call ReadFromAD(t)
                        PdTranSignalDbl = 1 'Random value to prevent from dividing by zero
                    Else
                        Call ReadFromAD(t) 'read reference, transmission and reflexion signal meanvalue 
                    End If



                    pd(runX, runY) = PdTranSignalDbl - CDbl(PdOffTran)
                    pdnorm(runX, runY) = (PdTranSignalDbl - CDbl(PdOffTran)) / (PdRefeSignalDbl - CDbl(PdOffRefe))
                    pdref(runX, runY) = PdRefeSignalDbl - CDbl(PdOffRefe)
                    pdreflex(runX, runY) = PdReflSignalDbl - CDbl(PdOffRefl)
                    pdreflexnorm(runX, runY) = (PdReflSignalDbl - CDbl(PdOffRefl)) / (PdRefeSignalDbl - CDbl(PdOffRefe))

                    pdsignalText.Text = Round(pd(runX, runY), 4)
                    normsignalText.Text = Round(pdnorm(runX, runY), 4)
                    reflexionText.Text = Round(pdreflex(runX, runY), 4)
                    reflexnormsignalText.Text = Round(pdreflexnorm(runX, runY), 4)
                    referenceText.Text = Round(pdref(runX, runY), 4)

                    If pdnorm(runX, runY) > MaxPdTrans Then 'hier wird gleich nach dem auslesen bestimmt ob es ein neues maximum oder minimum der Pd daten gibt damit das nicht jedesmal beim plotten gemacht werden muss
                        MaxPdTrans = pdnorm(runX, runY)
                    ElseIf pdnorm(runX, runY) < MinPdTrans Then
                        MinPdTrans = pdnorm(runX, runY)
                    End If
                    If pdreflexnorm(runX, runY) > MaxPdReflex Then
                        MaxPdReflex = pdreflexnorm(runX, runY)
                    ElseIf pdreflexnorm(runX, runY) < MinPdReflex Then
                        MinPdReflex = pdreflexnorm(runX, runY)
                    End If


                    Surv1.Text = MaxPdTrans ' Test for Surveilance
                    Surv2.Text = MinPdTrans


                    If PdTranSignalDbl >= PdMax Or PdRefeSignalDbl >= PdMax Then
                        If ShowSatCheckBox.Checked = True Then
                            PreviewColor = {255, 0, 0}
                        Else
                            PreviewColor = {255, 255, 255}
                        End If
                    ElseIf PdTranSignalDbl <= PdMin Or PdRefeSignalDbl <= PdMin Then
                        If ShowSatCheckBox.Checked = True Then
                            PreviewColor = {0, 0, 255}
                        Else
                            PreviewColor = {0, 0, 0}
                        End If
                    Else

                        Temp = Convert.ToInt32(255 / PdMax * (PdTranSignalDbl - CDbl(PdOffTran)))
                        If Temp < 0 Then
                            Temp = 0
                        End If
                        PreviewColor = {Temp, Temp, Temp}
                        'PreviewColor = {Convert.ToInt32(255 / PdMax * (PdTranSignalDbl - CDbl(PdOffTran))), Convert.ToInt32(255 / PdMax * (PdTranSignalDbl - CDbl(PdOffTran))), Convert.ToInt32(255 / PdMax * (PdTranSignalDbl - CDbl(PdOffTran)))}
                        End If

                        For n = 0 To zoom - 1 ' Writes the color values in an enlarged grid for display
                            For m = 0 To zoom - 1
                                drawingPreview.SetPixel(Convert.ToInt32((xstepcalc.Text - runX - 1) * zoom + n), Convert.ToInt32(runY * zoom + m), Color.FromArgb(PreviewColor(0), PreviewColor(1), PreviewColor(2)))
                            Next m
                        Next n
                        PictureBoxPreview.Image = drawingPreview
                        Application.DoEvents()

                Next

                'go back slowly to ystart without scanning-------------------------------------->>
                For runY = Convert.ToInt32(ystepcalc.Text - 1) To 0 Step -3
                    Call counter()
                    ysearchScroll.Value = ycalcendText.Text * 1000 - runY * ystepsizeText.Text
                    ysearchText.Text = ysearchScroll.Value / 1000
                    'SerialPortPiezo.Write("1ma0" + Str$(xsearchScroll.Value / 1000) + ",2ma0" + Str$(ysearchScroll.Value / 1000) + ",3ma0" + Str$(zsearchScroll.Value / 1000) + Chr(10)) ' Command for E 710
                    SerialPortPiezo.Write("MOV 1 " + Str$(xsearchScroll.Value / 1000) + " 2 " + Str$(ysearchScroll.Value / 1000) + " 3 " + Str$(zsearchScroll.Value / 1000) + Chr(10)) ' Command for E 725
                    Thread.Sleep(25) 'Timeout to let Piezo settle at each point
                    Application.DoEvents()
                Next
                runY = 0
                'go back slowly to ystart without scanning<<--------------------------------------

                ToolStripProgressBar.Value = runX

                PictureBoxMultiview.Width = 200 ' Plot 2D crosssection
                PictureBoxMultiview.Height = ystepcalc.Text * zoom
                Dim Multiview2D As New Bitmap(PictureBoxMultiview.Width, PictureBoxMultiview.Height)

                For i = 0 To ystepcalc.Text - 1 Step 1
                    If (MaxPdTrans - MinPdTrans) > 0 Then
                        For m = 0 To zoom - 1
                            Temp = Convert.ToInt32((pdnorm(runX, i) - MinPdTrans) / (MaxPdTrans - MinPdTrans) * 199)
                            If Temp < 1 Then
                                Temp = 1
                            ElseIf Temp > 199 Then
                                Temp = 199
                            End If
                            Multiview2D.SetPixel(Temp, Convert.ToInt32(i * zoom + m), Color.White)
                        Next m
                    End If
                Next
                PictureBoxMultiview.Image = Multiview2D

                s = 1 ' enable coordinate click on picturebox 1

            Next

            Call counter()

            statusLabel.Text = "saving files..."
            File1 = New StreamWriter(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "pddata" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".txt", True)
            File2 = New StreamWriter(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "pdnormdata" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".txt", True)
            File3 = New StreamWriter(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "pdreflexiondata" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".txt", True)
            File4 = New StreamWriter(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "pdreflexionnormdata" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".txt", True)
            File5 = New StreamWriter(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "pdrefdata" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".txt", True)


            For i = 0 To Convert.ToInt32(xstepcalc.Text) - 1 Step 1

                For k = 0 To Convert.ToInt32(ystepcalc.Text) - 1 Step 1

                    File1.Write(pd(i, k) & Chr(9))
                    File2.Write(pdnorm(i, k) & Chr(9))
                    File3.Write(pdreflex(i, k) & Chr(9))
                    File4.Write(pdreflexnorm(i, k) & Chr(9))
                    File5.Write(pdref(i, k) & Chr(9))

                Next

                File1.Write(Chr(10))
                File2.Write(Chr(10))
                File3.Write(Chr(10))
                File4.Write(Chr(10))
                File5.Write(Chr(10))

            Next

            File1.Close()
            File2.Close()
            File3.Close()
            File4.Close()
            File5.Close()
            File1 = Nothing
            File2 = Nothing
            File3 = Nothing
            File4 = Nothing
            File5 = Nothing

            If MaxPdTrans = MinPdTrans Then ' if there is no reasonable PD data this should prevent most of the crashes
                MaxPdTrans = 11
                MinPdTrans = 10
            End If
            If MaxPdReflex = MinPdReflex Then
                MaxPdReflex = 11
                MinPdReflex = 10
            End If

            Call saveimages() 'save pictures
            Call saveprotocolsashtml() 'for html protocol file

        Next

        MoveAbsoluteX(CDbl(xposText.Text)) 'Move back to center after scan is completed
        MoveAbsoluteY(CDbl(yposText.Text))
        MoveAbsoluteZ(CDbl(zposText.Text))
        'stop piezomovement<<-------------------------------

        Beep()
        statusLabel.Text = "measurement ready..."
        ToolStripProgressBar.Value = 0
        interruptButton.Enabled = False : stopButton.Enabled = False
        measureButton.Enabled = True : calculateButton.Enabled = True
        TextBoxMeasNo.Text = TextBoxMeasNo.Text + 1

    End Sub 'measurement end<<------------------------------------------------------

    Public Sub interruptMeasurement() Handles interruptButton.Click

        interrupt = interrupt + 1
        If (interrupt Mod 2) = 1 Then
            interruptButton.Text = "continue"
            statusLabel.Text = "measurement interrrupted..."
            Do While (interrupt Mod 2) = 1
                Threading.Thread.Sleep(100)
                Application.DoEvents()
            Loop
        End If

        If (interrupt Mod 2) = 0 Then
            interruptButton.Text = "interrupt"
            statusLabel.Text = "measurement " & (runZ + 1) & " of " & zstepcalc.Text & " is running..."
        End If

    End Sub

    Private Sub stopButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stopButton.Click
        If MsgBox("Do you want to quit the current measurement?", MsgBoxStyle.YesNo, "Are you really sure?") = MsgBoxResult.Yes Then
            ST = False
            Call stopMeasurement()
        End If
    End Sub

    Sub stopMeasurement()

        If CheckBoxCamTrigger.Checked Then 'MARKER: Weis nicht wozu das gut ist. Ich glaube es setzt das Trigger signal auf 0 aber soweit ich das sehe d�rfe eine unterbrechung nicht m�glich sein w�hrend das Triggersignal aktiv ist, da zwischen ein und aus kein Applications doevents steht
            Try
                myTask = New Task()
                myTask.AOChannels.CreateVoltageChannel("Dev1/ao1", "", PdMin, PdMax, AOVoltageUnits.Volts)
                Dim writer As AnalogSingleChannelWriter = New AnalogSingleChannelWriter(myTask.Stream)
                writer.WriteSingleSample(True, Convert.ToDouble(0))
            Catch ex As DaqException
                MessageBox.Show(ex.Message)
            Finally
                myTask.Dispose()
            End Try
        End If
        statusLabel.Text = "measurement stopped..."
        interruptButton.Text = "interrupt" ' This is just for the case that the measurement was first interrupted and then stopped
        interruptButton.Enabled = False : stopButton.Enabled = False
        measureButton.Enabled = True : calculateButton.Enabled = True

    End Sub

    'postprocessing------------------------------------------------------>>

    Sub autocontrastpreview() Handles showautocontrastButton.Click

        temprunX = runX
        temprunY = runY
        PictureBoxMultiview.Width = xstepcalc.Text * zoom
        PictureBoxMultiview.Height = ystepcalc.Text * zoom
        Dim DrawingMultiview As New Bitmap(PictureBoxMultiview.Width, PictureBoxMultiview.Height)

        For o = 0 To Convert.ToInt32(temprunX - 1) Step 1 ' Das -1 bewirkt hier das die Spalter welche aktuell gescannt wird nicht mit geplottet wird. Au�erdem wird bei einem 10x10 Scan runX von 0 bis 9 laufen und zum ende den wert 10 erreichen und somit den Loop von runX verlassen. D.h. runX durchl�uft 11 Werte. Das -1 verhindert somit auch das zum schluss Visual Studio versucht die 11. Spalte zu plotten, welche garnicht existiert.
            For p = 0 To Convert.ToInt32(ystepcalc.Text - 1) Step 1

                If ((pdnorm(o, p) - MinPdTrans) / (MaxPdTrans - MinPdTrans) * 255) > 255 Then ' MARKER: Soweit ich das sehe d�rfte dieser Fall nie erf�llt sein, genau wie der Zweite.
                    MultiviewColor = {255, 255, 255}
                ElseIf ((pdnorm(o, p) - MinPdTrans) / (MaxPdTrans - MinPdTrans) * 255) < 0 Then
                    MultiviewColor = {0, 0, 0}
                Else
                    MultiviewColor = {Convert.ToInt32(((pdnorm(o, p) - MinPdTrans) / (MaxPdTrans - MinPdTrans) * 255)), Convert.ToInt32(((pdnorm(o, p) - MinPdTrans) / (MaxPdTrans - MinPdTrans) * 255)), Convert.ToInt32(((pdnorm(o, p) - MinPdTrans) / (MaxPdTrans - MinPdTrans) * 255))}
                End If

                For n = 0 To zoom - 1 ' Writes the color values in a enlarged grid for display
                    For m = 0 To zoom - 1
                        DrawingMultiview.SetPixel((xstepcalc.Text - o - 1) * zoom + n, p * zoom + m, Color.FromArgb(MultiviewColor(0), MultiviewColor(1), MultiviewColor(2)))
                    Next m
                Next n

            Next
        Next
        PictureBoxMultiview.Image = DrawingMultiview

    End Sub

    Sub autocontrastcolorpreview() Handles showcontrastcolorButton.Click

        temprunX = runX
        temprunY = runY
        PictureBoxMultiview.Width = xstepcalc.Text * zoom
        PictureBoxMultiview.Height = ystepcalc.Text * zoom
        Dim DrawingMultiview As New Bitmap(PictureBoxMultiview.Width, PictureBoxMultiview.Height)

        For i = 0 To Convert.ToInt32(temprunX - 1) Step 1
            For k = 0 To Convert.ToInt32(ystepcalc.Text - 1) Step 1
                f(i, k) = 7 * ((pdnorm(i, k) - MinPdTrans) / (MaxPdTrans - MinPdTrans)) ' like a normalization but to 7 instead of 1 like usually. This is to calculate in the seven colors
            Next
        Next

        For o = 0 To Convert.ToInt32(temprunX - 1) Step 1
            For p = 0 To Convert.ToInt32(ystepcalc.Text - 1) Step 1

                If f(o, p) > 7 Then ' MARKER: Same like for autocontrastpreview: Soweit ich das sehe d�rfte dieser Fall nie erf�llt sein, genau wie der Zweite.
                    MultiviewColor = {255, 0, 0}
                ElseIf f(o, p) < 0 Then
                    MultiviewColor = {0, 0, 255}
                Else
                    ' Creates a colormap: black - purple - blue - cyan - green - yellow - red - white
                    If (f(o, p)) >= 0 And (f(o, p)) <= 1 Then ' black-purple
                        MultiviewColor = {Convert.ToInt32((f(o, p)) * 255), 0, Convert.ToInt32((f(o, p)) * 255)}
                    ElseIf (f(o, p)) > 1 And (f(o, p)) <= 2 Then ' purple - blue
                        MultiviewColor = {Convert.ToInt32(255 - ((f(o, p) - 1) * 255)), 0, 255}
                    ElseIf (f(o, p)) > 2 And (f(o, p)) <= 3 Then ' blue - cyan
                        MultiviewColor = {0, Convert.ToInt32((f(o, p) - 2) * 255), 255}
                    ElseIf (f(o, p)) > 3 And (f(o, p)) <= 4 Then ' cyan - green
                        MultiviewColor = {0, 255, Convert.ToInt32(255 - ((f(o, p) - 3) * 255))}
                    ElseIf (f(o, p)) > 4 And (f(o, p)) <= 5 Then ' green - yellow
                        MultiviewColor = {Convert.ToInt32((f(o, p) - 4) * 255), 255, 0}
                    ElseIf (f(o, p)) > 5 And (f(o, p)) <= 6 Then ' yellow - red
                        MultiviewColor = {255, Convert.ToInt32(255 - ((f(o, p) - 5) * 255)), 0}
                    Else ' (f(o, p)) > 6 And (f(o, p)) <= 7 Then ' red - white
                        MultiviewColor = {255, Convert.ToInt32((f(o, p) - 6) * 255), Convert.ToInt32((f(o, p) - 6) * 255)}
                    End If
                End If

                For n = 0 To zoom - 1 ' Writes the color values in a enlarged grid for display
                    For m = 0 To zoom - 1
                        DrawingMultiview.SetPixel((xstepcalc.Text - o - 1) * zoom + n, p * zoom + m, Color.FromArgb(MultiviewColor(0), MultiviewColor(1), MultiviewColor(2)))
                    Next m
                Next n

            Next
        Next
        PictureBoxMultiview.Image = DrawingMultiview
    End Sub

    Sub autocontrastreflexpreview() Handles showautocontrastreflexButton.Click

        temprunX = runX
        temprunY = runY
        PictureBoxMultiview.Width = xstepcalc.Text * zoom
        PictureBoxMultiview.Height = ystepcalc.Text * zoom
        Dim DrawingMultiview As New Bitmap(PictureBoxMultiview.Width, PictureBoxMultiview.Height)

        For o = 0 To Convert.ToInt32(temprunX - 1) Step 1
            For p = 0 To Convert.ToInt32(ystepcalc.Text - 1) Step 1

                If ((pdreflexnorm(o, p) - MinPdReflex) / (MaxPdReflex - MinPdReflex) * 255) > 255 Then ' MARKER: Same like for autocontrastpreview: Soweit ich das sehe d�rfte dieser Fall nie erf�llt sein, genau wie der Zweite.
                    MultiviewColor = {255, 255, 255}
                ElseIf ((pdreflexnorm(o, p) - MinPdReflex) / (MaxPdReflex - MinPdReflex) * 255) < 0 Then
                    MultiviewColor = {0, 0, 0}
                Else
                    MultiviewColor = {Convert.ToInt32(((pdreflexnorm(o, p) - MinPdReflex) / (MaxPdReflex - MinPdReflex) * 255)), Convert.ToInt32(((pdreflexnorm(o, p) - MinPdReflex) / (MaxPdReflex - MinPdReflex) * 255)), Convert.ToInt32(((pdreflexnorm(o, p) - MinPdReflex) / (MaxPdReflex - MinPdReflex) * 255))}
                End If

                For n = 0 To zoom - 1 ' Writes the color values in a enlarged grid for display
                    For m = 0 To zoom - 1
                        DrawingMultiview.SetPixel((xstepcalc.Text - o - 1) * zoom + n, p * zoom + m, Color.FromArgb(MultiviewColor(0), MultiviewColor(1), MultiviewColor(2)))
                    Next m
                Next n

            Next
        Next
        PictureBoxMultiview.Image = DrawingMultiview
    End Sub

    Sub autocontrastreflexcolorpreview() Handles showreflexcolorButton.Click

        temprunX = runX
        temprunY = runY
        PictureBoxMultiview.Width = xstepcalc.Text * zoom
        PictureBoxMultiview.Height = ystepcalc.Text * zoom
        Dim DrawingMultiview As New Bitmap(PictureBoxMultiview.Width, PictureBoxMultiview.Height)

        For i = 0 To Convert.ToInt32(temprunX - 1) Step 1
            For k = 0 To Convert.ToInt32(ystepcalc.Text - 1) Step 1
                f(i, k) = 7 * ((pdreflexnorm(i, k) - MinPdReflex) / (MaxPdReflex - MinPdReflex))
            Next
        Next

        For o = 0 To Convert.ToInt32(temprunX - 1) Step 1
            For p = 0 To Convert.ToInt32(ystepcalc.Text - 1) Step 1

                If f(o, p) > 7 Then ' MARKER: Same like for autocontrastpreview: Soweit ich das sehe d�rfte dieser Fall nie erf�llt sein, genau wie der Zweite.
                    MultiviewColor = {255, 0, 0}
                ElseIf f(o, p) < 0 Then
                    MultiviewColor = {0, 0, 255}
                Else
                    ' Creates a colormap: black - purple - blue - cyan - green - yellow - red - white
                    If (f(o, p)) >= 0 And (f(o, p)) <= 1 Then ' black-purple
                        MultiviewColor = {Convert.ToInt32((f(o, p)) * 255), 0, Convert.ToInt32((f(o, p)) * 255)}
                    ElseIf (f(o, p)) > 1 And (f(o, p)) <= 2 Then ' purple - blue
                        MultiviewColor = {Convert.ToInt32(255 - ((f(o, p) - 1) * 255)), 0, 255}
                    ElseIf (f(o, p)) > 2 And (f(o, p)) <= 3 Then ' blue - cyan
                        MultiviewColor = {0, Convert.ToInt32((f(o, p) - 2) * 255), 255}
                    ElseIf (f(o, p)) > 3 And (f(o, p)) <= 4 Then ' cyan - green
                        MultiviewColor = {0, 255, Convert.ToInt32(255 - ((f(o, p) - 3) * 255))}
                    ElseIf (f(o, p)) > 4 And (f(o, p)) <= 5 Then ' green - yellow
                        MultiviewColor = {Convert.ToInt32((f(o, p) - 4) * 255), 255, 0}
                    ElseIf (f(o, p)) > 5 And (f(o, p)) <= 6 Then ' yellow - red
                        MultiviewColor = {255, Convert.ToInt32(255 - ((f(o, p) - 5) * 255)), 0}
                    Else ' (f(o, p)) > 6 And (f(o, p)) <= 7 Then ' red - white
                        MultiviewColor = {255, Convert.ToInt32((f(o, p) - 6) * 255), Convert.ToInt32((f(o, p) - 6) * 255)}
                    End If
                End If

                For n = 0 To zoom - 1 ' Writes the color values in a enlarged grid for display
                    For m = 0 To zoom - 1
                        DrawingMultiview.SetPixel((xstepcalc.Text - o - 1) * zoom + n, p * zoom + m, Color.FromArgb(MultiviewColor(0), MultiviewColor(1), MultiviewColor(2)))
                    Next m
                Next n

            Next
        Next
        PictureBoxMultiview.Image = DrawingMultiview

    End Sub


    Private Sub saveprotocolsashtml() ' This function creates the html file which contains the measurement protocol

        statusLabel.Text = "saving files..."
        Dim dir As IO.DirectoryInfo = IO.Directory.CreateDirectory(Rootdir + "\" + TextBoxMeasName.Text)
        File9 = New StreamWriter(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "protocol" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".html", True)

        File9.Write("<!-- saved from url=(0013)about:internet -->" + Chr(10))
        File9.Write("<html>" + Chr(10))

        File9.Write("<head>" + Chr(10))
        File9.Write("<meta name=""GENERATOR"" content=""Lord of the split rings"">" + Chr(10))
        File9.Write("<meta http-equiv=""Content-Type"" content=""text/html; charset=windows-1252"">" + Chr(10))
        File9.Write("<title>SRR measurement protocol file</title>" + Chr(10))

        File9.Write(" <style type=""text/css"">" + Chr(10))
        File9.Write("<!--" + Chr(10))
        File9.Write("h2 {color: #4682B4; font-family: verdana;}" + Chr(10))
        File9.Write("td.data1 {width: 40%; text-align: left;}" + Chr(10))
        File9.Write("td.data2 {width: 60%; text-align: left;}" + Chr(10))
        File9.Write("td.data3 {width: 100%; text-align: left; color: #4682B4; font-size: 20px;}" + Chr(10))
        File9.Write("td.data4 {width: 100%; text-align: left; color: #468200; font-size: 25px;}" + Chr(10))
        File9.Write("td.data5 {width: 50%; text-align: left;  color: #4682B4; font-size: 20px;}" + Chr(10))
        File9.Write("-->" + Chr(10))
        File9.Write("</style>" + Chr(10))

        File9.Write("</head>" + Chr(10))

        File9.Write("<body align=""center"" text=""800000"" bgcolor=""#F4F8FC"">" + Chr(10))

        File9.Write("<h2><u>" & TextBoxWavelength.Text & "nm / " & TextBoxPol.Text & "</u> protocol file<br>" & DateTime.Now & "</h2>" & Chr(10))

        File9.Write("<table border=""0"" cellspacing=""3"" width=""500px"">")

        File9.Write("<tr><td class=""data4"">structure / sample properties</td></tr>")
        File9.Write("<tr><td class=""data1""><b>structure</b></td><td class=""data2""><b>" & TextBoxMeasName.Text & "</b></td></tr>")
        File9.Write("<tr><td class=""data1"">structure size</td><td class=""data2"">" & TextBoxSample.Text & "</td></tr>")

        File9.Write("<tr><td class=""data4"">measurement results</td></tr>")
        File9.Write("<tr><td class=""data5"">transnorm(auto)</td><td class=""data5"">transcolor(auto)</td></tr>")
        File9.Write("<tr><td class=""data5""><img src=""" & TextBoxMeasNo.Text & "transnormauto" & TextBoxMeasName.Text & TextBoxPol.Text & "z" & zsearchText.Text.Replace(".", "k") & ".bmp" & """ border=""2"" alt=""""></td><td class=""data5""><img src=""" & TextBoxMeasNo.Text & "transcolorauto" & TextBoxMeasName.Text & TextBoxPol.Text & "z" & zsearchText.Text.Replace(".", "k") & ".bmp" & """ border=""2"" alt=""""></td></tr>")
        File9.Write("<tr><td class=""data5"">reflexion(auto)</td><td class=""data5"">reflexcolor(auto)</td></tr>")
        File9.Write("<tr><td class=""data5""><img src=""" & TextBoxMeasNo.Text & "reflexauto" & TextBoxMeasName.Text & TextBoxPol.Text & "z" & zsearchText.Text.Replace(".", "k") & ".bmp" & """ border=""2"" alt=""""></td><td class=""data5""><img src=""" & TextBoxMeasNo.Text & "reflexcolorauto" & TextBoxMeasName.Text & TextBoxPol.Text & "z" & zsearchText.Text.Replace(".", "k") & ".bmp" & """ border=""2"" alt=""""></td></tr>")

        File9.Write("<tr><td class=""data3"">special values</td></tr>") 'MARKER: Hier stimmt irgendwas nicht, im protokollfile wird hier zweimal der selbe wert abgespeichert
        File9.Write("<tr><td class=""data1""><b>maximal transmission<br>(Pd signal)</b></td><td class=""data2""><b>" & MaxPdTrans & "</b></td></tr>")

        File9.Write("<tr><td class=""data3"">position (mikrom)</td></tr>")
        File9.Write("<tr><td class=""data1"">x</td><td class=""data2"">" & xposText.Text & "</td></tr>")
        File9.Write("<tr><td class=""data1"">y</td><td class=""data2"">" & yposText.Text & "</td></tr>")
        File9.Write("<tr><td class=""data1""><b>z</b></td><td class=""data2""><b>" & zsearchText.Text & "</b><br> </td></tr>")

        File9.Write("<tr><td class=""data3"">stepsize (nm)</td></tr>")
        File9.Write("<tr><td class=""data1"">x</td><td class=""data2"">" & xstepsizeText.Text & "</td></tr>")
        File9.Write("<tr><td class=""data1"">y</td><td class=""data2"">" & ystepsizeText.Text & "</td></tr>")
        File9.Write("<tr><td class=""data1"">z</td><td class=""data2"">" & zstepsizeText.Text & "<br> </td></tr>")

        File9.Write("<tr><td class=""data3"">scanfield (mikrom)</td></tr>")
        File9.Write("<tr><td class=""data1"">x</td><td class=""data2"">" & xcalcstartText.Text & " to " & xcalcendText.Text & "</td></tr>")
        File9.Write("<tr><td class=""data1"">y</td><td class=""data2"">" & ycalcstartText.Text & " to " & ycalcendText.Text & "</td></tr>")
        File9.Write("<tr><td class=""data1"">z</td><td class=""data2"">" & zcalcstartText.Text & " to " & zcalcendText.Text & "<br> </td></tr>")

        File9.Write("<tr><td class=""data3"">image resolution (pixel)<br>(total no. of steps in x-y-direction)</td></tr>")
        File9.Write("<tr><td class=""data1"">x</td><td class=""data2"">" & xstepcalc.Text & "</td></tr>")
        File9.Write("<tr><td class=""data1"">y</td><td class=""data2"">" & ystepcalc.Text & "<br> </td></tr>")

        File9.Write("<tr><td class=""data3"">presettings</td></tr>")
        File9.Write("<tr><td class=""data1""><b>scan direction</b></td><td class=""data2""><b>" & scandirection & "</b></td></tr>")
        File9.Write("<tr><td class=""data1""><b>wavelength</b></td><td class=""data2""><b>" & TextBoxWavelength.Text & "</b></td></tr>")
        File9.Write("<tr><td class=""data1""><b>polarisation</b></td><td class=""data2""><b>" & TextBoxPol.Text & "</b></td></tr>")
        File9.Write("<tr><td class=""data1"">offset</td><td class=""data2"">" & PdOffTran & "</td></tr>")
        File9.Write("<tr><td class=""data1"">reflexion offset</td><td class=""data2"">" & PdOffRefl & "</td></tr>")
        File9.Write("<tr><td class=""data1"">reference offset</td><td class=""data2"">" & PdOffRefe & "</td></tr>")
        File9.Write("<tr><td class=""data1""><b>averaging</b></td><td class=""data2""><b>" & averageText.Text & "x</b></td></tr>")
        File9.Write("<tr><td class=""data1""><b>time</b></td><td class=""data2""><b>" & TextBoxTime.Text & "</b></td></tr>")
        File9.Write("</table>")

        File9.Write("</body>" + Chr(10))
        File9.Write("</html>")

        File9.Close()
        File9 = Nothing

    End Sub

    Private Sub saveimages()

        Call autocontrastpreview()
        PictureBoxMultiview.Image.Save(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "transnormauto" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".bmp", ImageFormat.Bmp)
        Call autocontrastcolorpreview()
        PictureBoxMultiview.Image.Save(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "transcolorauto" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".bmp", ImageFormat.Bmp)

        'Call autocontrastreflexpreview() 'MARKER: I deactivated the relfection images, because 90% we dont have reflection diode
        'PictureBoxMultiview.Image.Save(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "reflexauto" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".bmp", ImageFormat.Bmp)
        'Call autocontrastreflexcolorpreview()
        'PictureBoxMultiview.Image.Save(Rootdir + "\" + TextBoxMeasName.Text + "\" + TextBoxMeasNo.Text + "reflexcolorauto" + TextBoxMeasName.Text + TextBoxPol.Text + "z" + zsearchText.Text.Replace(".", "k") + ".bmp", ImageFormat.Bmp)

    End Sub

    'postprocessing end<<------------------------------------------------------

    Private Sub CaliLC1_Click(sender As System.Object, e As System.EventArgs) Handles ButtonCaliLC1.Click

        LC0min = TextBoxCaliStart.Text
        LC0max = TextBoxCaliEnd.Text
        Nmeas = TextBoxCaliSteps.Text
        TT = TextBoxCaliDelay.Text
        stepsize = (LC0max - LC0min) / Nmeas
        ToolStripProgressBar.Maximum = Convert.ToInt32(Nmeas)

        ArcoptixLC.SetDACVoltage(LC0min, 0)
        Thread.Sleep(3000)
        stopButton.Enabled = True

        For n = 0 To Nmeas

            If ST = False Then
                Exit Sub
            End If
            Application.DoEvents()
            ArcoptixLC.SetDACVoltage(LC0min + stepsize * n, 0)
            Thread.Sleep(TT)
            myTask = New Task()
            myTask.AOChannels.CreateVoltageChannel("Dev1/ao1", "", PdMin, PdMax, AOVoltageUnits.Volts)

            Dim writer As AnalogSingleChannelWriter = New AnalogSingleChannelWriter(myTask.Stream)
            writer.WriteSingleSample(True, Convert.ToDouble(5)) ' Trigger Signal to camera
            Thread.Sleep(1)
            writer.WriteSingleSample(True, Convert.ToDouble(0))
            Thread.Sleep(1)
            ToolStripProgressBar.Value = n
        Next
        ToolStripProgressBar.Value = 0
        stopButton.Enabled = False
    End Sub








    ' Code for focussearch --------------------------------------------------------------------------------------------------------------

    Dim pdSignalDbl As Double
    Dim pdSignalMatrix(400) As Double
    Dim pdRefSignalDbl As Double
    Dim pdRefSignalMatrix(400) As Double
    Dim run As Double
    Dim run2 As Double
    Dim run3 As Double
    Dim linepixel As Integer
    Dim currentZ As Double
    Dim drawing_trans As New Bitmap(401, 120)
    Dim drawing_refl As New Bitmap(401, 120)
    Dim graph_trans, graph_refl As Graphics
    Dim maxTran, maxRefl, max3, minTran, minRefl, min3 As Double
    Dim finescan_start, finescan_stop As Double
    Dim finescan_center_tmp, finescan_step_tmp As Double

    Private Sub focussearchButton_Click(sender As Object, e As EventArgs) Handles focussearchButton.Click
        TabControlView.SelectedIndex = 1
        TextBoxFFxpos.Text = xposText.Text
        TextBoxFFypos.Text = yposText.Text
    End Sub

    Private Sub findfocusButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonFF.Click

        transminText.Text = ""
        reflexmaxText.Text = ""
        graph_trans = Graphics.FromImage(drawing_trans)
        graph_trans.Clear(Color.SteelBlue)
        graph_refl = Graphics.FromImage(drawing_refl)
        graph_refl.Clear(Color.SteelBlue)
        PictureBox_trans.Image = drawing_trans
        PictureBox_refl.Image = drawing_refl
        Array.Clear(pdSignalMatrix, 0, 401)
        Array.Clear(pdRefSignalMatrix, 0, 401)
        ToolStripProgressBar.Maximum = 401

        initializePiezo()

        finescan_start = CDbl(TextBoxFFcenter.Text) - (200 / 1000 * CDbl(finescan_step.Text))
        finescan_stop = CDbl(TextBoxFFcenter.Text) + (200 / 1000 * CDbl(finescan_step.Text))
        MoveAbsoluteX(CDbl(TextBoxFFxpos.Text))
        MoveAbsoluteY(CDbl(TextBoxFFypos.Text))

        If finescan_start < 0 Or finescan_stop > 20 Then
            MsgBox("Scan values out of range!", MsgBoxStyle.OkOnly, "Warning!")
        Else
            For run = 0 To 400 Step 1 'first run to collect data
                run3 = CDbl(TextBoxFFcenter.Text) - (200 / 1000 * CDbl(finescan_step.Text)) + (run / 1000 * CDbl(finescan_step.Text))
                MoveAbsoluteZ(run3)
                Threading.Thread.Sleep(15) 'Martin
                Call ReadFromAD(200) 'Martin

                pdSignalMatrix(Round(run, 0)) = PdTranSignalDbl
                pdRefSignalMatrix(Round(run, 0)) = PdReflSignalDbl

                Application.DoEvents()
                ToolStripProgressBar.Value = run
            Next

            maxTran = FuncMax(pdSignalMatrix)
            maxRefl = FuncMax(pdRefSignalMatrix)
            minTran = FuncMin(pdSignalMatrix)
            minRefl = FuncMin(pdRefSignalMatrix)

            If maxTran = minTran Then ' should avoid crashes du to dividing through zero for constant signals
                maxTran = maxTran + 1
                minTran = minTran - 1
            End If
            If maxRefl = minRefl Then
                maxRefl = maxRefl + 1
                minRefl = minRefl - 1
            End If

            For run2 = 0 To 400 Step 1 'second run to plot data

                Application.DoEvents()

                If pdSignalMatrix(run2) >= 0 Then

                    drawing_trans.SetPixel(run2, Convert.ToInt32(119 - (pdSignalMatrix(run2) - minTran) / (maxTran - minTran) * 119), Color.White)
                    PictureBox_trans.Image = drawing_trans

                    If pdSignalMatrix(run2) = minTran Then 'MARKER hier wird ne vertikale linie geplottet beim kleinsten gemessenen wert
                        For linepixel = 0 To 119 Step 1
                            drawing_trans.SetPixel(run2, linepixel, Color.Maroon)
                        Next
                    End If

                End If

                If pdRefSignalMatrix(run2) >= 0 Then

                    If maxRefl - minRefl = 0 Then minRefl = 0
                    drawing_refl.SetPixel(run2, Convert.ToInt32(119 - (pdRefSignalMatrix(run2) - minRefl) / (maxRefl - minRefl) * 119), Color.White)
                    PictureBox_refl.Image = drawing_refl

                    If pdRefSignalMatrix(run2) = maxRefl Then
                        For linepixel = 0 To 119 Step 1
                            drawing_refl.SetPixel(run2, linepixel, Color.Maroon)
                        Next
                    End If

                End If

            Next

            finescan_center_tmp = TextBoxFFcenter.Text
            finescan_step_tmp = finescan_step.Text

        End If

        ToolStripProgressBar.Value = 0

    End Sub

    Private Sub PictureBox_trans_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox_trans.MouseMove
        Dim pt As Point = PictureBox_trans.PointToClient(Control.MousePosition)
        currentZ = pt.X
        mouseoverzText.Text = Round(finescan_center_tmp - (200 / 1000 * finescan_step_tmp) + (currentZ / 1000 * finescan_step_tmp), 2)
    End Sub

    Private Sub PictureBox_trans_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox_trans.Click
        transminText.Text = Round(finescan_center_tmp - (200 / 1000 * finescan_step_tmp) + (currentZ / 1000 * finescan_step_tmp), 2)
    End Sub

    Private Sub PictureBox_refl_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox_refl.MouseMove
        Dim pt As Point = PictureBox_refl.PointToClient(Control.MousePosition)
        currentZ = pt.X
        mouseoverzText.Text = Round(finescan_center_tmp - (200 / 1000 * finescan_step_tmp) + (currentZ / 1000 * finescan_step_tmp), 2)
    End Sub

    Private Sub PictureBox_refl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox_refl.Click
        reflexmaxText.Text = Round(finescan_center_tmp - (200 / 1000 * finescan_step_tmp) + (currentZ / 1000 * finescan_step_tmp), 2)
    End Sub

    Public Sub finescan_step_Change() Handles finescan_step.TextChanged
        finescan_range.Text = Round(finescan_step.Text * 400 / 1000, 2)
    End Sub

    Private Sub ButtonTransferTran_Click(sender As Object, e As EventArgs) Handles ButtonTransferTran.Click
        MoveAbsoluteZ(CDbl(transminText.Text))
        zposText.Text = transminText.Text
    End Sub

    Private Sub ButtonTransferRefl_Click(sender As Object, e As EventArgs) Handles ButtonTransferRefl.Click
        MoveAbsoluteZ(CDbl(reflexmaxText.Text))
        zposText.Text = reflexmaxText.Text
    End Sub


    'Dim Bmove As Integer = 0
    'Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.MouseMove
    '    If Bmove = 0 Then
    '        Button1.Location = New Point(300, 300)
    '        Bmove = 1
    '    Else
    '        Button1.Location = New Point(220, 300)
    '        Bmove = 0
    '    End If
    'End Sub

End Class